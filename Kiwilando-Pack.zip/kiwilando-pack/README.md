# Kiwilando Pack (resource pack)

Pack unique du plugin Kiwilando : karts, armes paintball, zombies, menus des jeux, badges de grade, menus du staff.

```
resource-pack/        # le pack (pack.mcmeta + assets/)
resource-pack-src/    # scripts Python qui (re)dessinent les textures
.github/workflows/    # zip + SHA-1 + release "latest" automatiques
```

## Mise en ligne
1. Dépôt GitHub **public**, pousse ce dossier sur `main`.
2. L'action crée la release `latest` : `Kiwilando-Pack.zip` + SHA-1 dans la description.
3. Dans le plugin, `plugins/Kiwilando/admin/pack.yml` :
   ```yaml
   url: "https://github.com/TON_PSEUDO/kiwilando-pack/releases/latest/download/Kiwilando-Pack.zip"
   sha1: "LE_SHA1_DE_LA_RELEASE"     # facultatif
   ```
   (ou `pack.url` dans `config.yml`). Recharge avec `/kiwilando reload`, puis `/kiwilando pack` pour vérifier.
4. Après chaque modification du pack, le SHA-1 change : mets-le à jour (ou laisse `sha1` vide).

## Regénérer des textures (Python + Pillow)
Depuis la racine du dépôt :
```
python3 resource-pack-src/generer_pack_admin.py resource-pack
python3 resource-pack-src/generer_zombies.py resource-pack
python3 resource-pack-src/generer_hud_paintball.py resource-pack
```
