# Kiwilando Pack (resource pack)

Resource pack des cosmétiques 3D de KiwiLand (plugin **kiwilando-plugin**).
Tous les cosmétiques (v8.1) utilisent l'item `PAPER` avec un `CustomModelData` (1001 → 1019) : seul le papier est modifié, aucun autre item vanilla n'est touché.

## Structure

```
kiwilando-pack/
├── pack.mcmeta · pack.png
├── cosmetics.json                       # source de vérité : id, rareté, type, CMD, item de base (paper)
├── assets/minecraft/
│   ├── models/item/paper.json           # modèle de base + 19 overrides CustomModelData
│   ├── models/item/cosmetics/*.json     # un modèle par cosmétique
│   └── textures/item/cosmetics/*.png    # une texture 16x16 par cosmétique
├── tools/generate.py                    # génère modèles + textures
└── .github/workflows/release.yml        # zip + SHA-1 + release automatique
```

## Utilisation

1. Crée un dépôt GitHub **public** `kiwilando-pack` et pousse ce dossier sur `main`.
2. L'action GitHub crée la release `latest` avec `KiwilandoPack.zip` et le **SHA-1** (dans la description de la release).
3. Dans `server.properties` du serveur :
   ```
   resource-pack=https://github.com/TON_PSEUDO/kiwilando-pack/releases/latest/download/KiwilandoPack.zip
   resource-pack-sha1=LE_SHA1_DE_LA_RELEASE
   require-resource-pack=true
   ```
4. Redémarre le serveur. Après chaque mise à jour du pack, mets à jour le `resource-pack-sha1`.

## Modifier / ajouter des textures

- **Tes propres textures** : remplace un PNG dans `assets/minecraft/textures/item/cosmetics/` (même nom de fichier).
- **Nouveau cosmétique** : ajoute une ligne dans `cosmetics.json` (le `cmd` doit être identique à celui de `CosmeticDefinition.java`), puis :
  ```
  pip install pillow
  python tools/generate.py
  ```
  Cela crée le modèle, l'override et une texture provisoire (les textures existantes ne sont pas écrasées ; `--force` pour tout régénérer).

## Notes

- `pack_format` 34 = Minecraft 1.21 / 1.21.1. À changer si tu montes de version.
- Les textures fournies sont des **placeholders** (forme + couleur de rareté), à remplacer par ton vrai pixel art.
