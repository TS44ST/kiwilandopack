#!/usr/bin/env python3
"""
Génère les modèles (assets/minecraft/models/item) et les textures 16x16
(assets/minecraft/textures/item/cosmetics) à partir de cosmetics.json.

  python tools/generate.py           # crée seulement ce qui manque
  python tools/generate.py --force   # régénère aussi les textures existantes

Pour utiliser tes propres textures : remplace le PNG correspondant dans
assets/minecraft/textures/item/cosmetics/ (même nom) et ne lance pas --force.
Dépendance : pip install pillow
"""
import json, sys
from collections import defaultdict
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
MODELS = ROOT / "assets/minecraft/models/item"
TEXTURES = ROOT / "assets/minecraft/textures/item/cosmetics"
FORCE = "--force" in sys.argv

RARITY_COLORS = {
    "COMMUN": (170, 170, 170), "PEU_COMMUN": (90, 200, 90), "RARE": (70, 110, 255),
    "EPIC": (150, 60, 200), "LEGENDAIRE": (255, 170, 0), "MYTHIC": (230, 50, 60),
    "DIVIN": (255, 60, 170),
}
KIWI = (130, 190, 40)


def shade(c, f):
    return tuple(max(0, min(255, int(v * f))) for v in c)


def draw_shape(kind, d, main, accent):
    if kind == "hat":
        d.rectangle((4, 5, 11, 9), fill=main)
        d.rectangle((2, 10, 13, 11), fill=shade(main, 0.8))
        d.rectangle((5, 6, 6, 7), fill=accent)
    elif kind == "trail":
        for (x, y, s) in [(2, 12, 2), (5, 10, 2), (8, 7, 2), (11, 4, 2), (13, 2, 1)]:
            d.rectangle((x, y, x + s - 1, y + s - 1), fill=main)
        d.point((9, 8), fill=accent)
    elif kind == "aura":
        d.ellipse((2, 2, 13, 13), outline=main, width=2)
        d.rectangle((7, 7, 8, 8), fill=accent)
    elif kind == "backpack":
        d.rectangle((4, 3, 11, 13), fill=main)
        d.rectangle((6, 8, 9, 11), fill=accent)
        d.line((4, 3, 4, 7), fill=shade(main, 0.7))
        d.line((11, 3, 11, 7), fill=shade(main, 0.7))
    elif kind in ("wings", "wingshalo"):
        d.polygon([(7, 8), (1, 3), (2, 10), (5, 13)], fill=main)
        d.polygon([(8, 8), (14, 3), (13, 10), (10, 13)], fill=main)
        d.point((3, 6), fill=accent)
        d.point((12, 6), fill=accent)
        if kind == "wingshalo":
            d.ellipse((5, 0, 10, 3), outline=accent)
    elif kind == "mount":
        d.rectangle((3, 7, 12, 10), fill=main)
        d.rectangle((7, 4, 8, 6), fill=accent)
        d.rectangle((3, 11, 4, 14), fill=shade(main, 0.7))
        d.rectangle((11, 11, 12, 14), fill=shade(main, 0.7))
    else:
        d.rectangle((3, 3, 12, 12), fill=main)


def add_outline(img, color):
    px = img.load()
    w, h = img.size
    marks = []
    for y in range(h):
        for x in range(w):
            if px[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h and px[nx, ny][3] > 0:
                        marks.append((x, y))
                        break
    for x, y in marks:
        px[x, y] = color + (255,)


def make_texture(item, path):
    main = RARITY_COLORS.get(item["rarity"], (200, 200, 200))
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    draw_shape(item["type"], ImageDraw.Draw(img), main, KIWI)
    add_outline(img, shade(main, 0.35))
    img.save(path)


def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main():
    items = json.loads((ROOT / "cosmetics.json").read_text(encoding="utf-8"))
    TEXTURES.mkdir(parents=True, exist_ok=True)
    by_material = defaultdict(list)

    for it in items:
        tex = TEXTURES / f"{it['id']}.png"
        if FORCE or not tex.exists():
            make_texture(it, tex)
        write_json(MODELS / "cosmetics" / f"{it['id']}.json", {
            "parent": "item/generated",
            "textures": {"layer0": f"item/cosmetics/{it['id']}"},
        })
        by_material[it["material"]].append(it)

    for material, group in by_material.items():
        write_json(MODELS / f"{material}.json", {
            "parent": "item/generated",
            "textures": {"layer0": f"item/{material}"},
            "overrides": [
                {"predicate": {"custom_model_data": g["cmd"]}, "model": f"item/cosmetics/{g['id']}"}
                for g in sorted(group, key=lambda g: g["cmd"])
            ],
        })

    if FORCE or not (ROOT / "pack.png").exists():
        icon = Image.new("RGBA", (64, 64), KIWI + (255,))
        ImageDraw.Draw(icon).ellipse((14, 14, 49, 49), fill=(90, 140, 30, 255), outline=(40, 70, 10, 255), width=3)
        icon.save(ROOT / "pack.png")
    print(f"OK : {len(items)} cosmétiques, {len(by_material)} modèles de base.")


if __name__ == "__main__":
    main()
