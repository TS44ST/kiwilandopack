#!/usr/bin/env python3
"""
HUD et equipement du paintball Kiwilando (dessine tout, aucune image externe).
Usage (depuis le dossier du projet) : python3 resource-pack-src/generer_hud_paintball.py resource-pack

Ecrit dans le pack :
  - polices kiwilando:hud (panneaux + icones), kiwilando:hud_y<N> (texte et icones decales vers le bas),
    kiwilando:hud_center (hitmarker au centre de l'ecran, via le sous-titre)
  - barre de boss ROSE invisible (le HUD du haut s'affiche dans son titre)
  - masque de paintball (equipement teintable + icone), grenade de peinture (modele teinte), lunette et visiere
Les decalages (HUD_Y) doivent rester identiques a PaintballHud.java.
"""
import json
import math
import os
import sys

from PIL import Image, ImageDraw, ImageFilter

OUT = sys.argv[1] if len(sys.argv) > 1 else "resource-pack"
A = os.path.join(OUT, "assets")
HUD_Y = [2, 13, 24, 35]          # lignes decalees (pixels vers le bas) utilisees par le HUD


def path(*p):
    f = os.path.join(A, *p)
    os.makedirs(os.path.dirname(f), exist_ok=True)
    return f


def save(img, *p):
    img.save(path(*p))


def jdump(obj, *p):
    with open(path(*p), "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=True)


def rr(d, box, r, fill=None, outline=None, width=1):
    d.rounded_rectangle(box, radius=r, fill=fill, outline=outline, width=width)


# ======================================================================= panneaux
def timer_panel():
    w, h = 52, 16
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    rr(d, [0, 0, w - 1, h - 1], 4, fill=(13, 17, 24, 228), outline=(255, 255, 255, 46))
    d.line([(4, 1), (w - 5, 1)], fill=(255, 255, 255, 34))           # reflet en haut
    d.line([(6, h - 2), (w - 7, h - 2)], fill=(126, 231, 135, 150))  # liseré kiwi en bas
    return im


def team_panel():
    """Blanc : la couleur de l'equipe est appliquee par la couleur du texte."""
    w, h = 34, 16
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    rr(d, [0, 0, w - 1, h - 1], 4, fill=(255, 255, 255, 205))
    for y in range(h // 2, h - 1):                                    # bas un peu plus sombre (volume)
        a = int(205 - (y - h // 2) * 7)
        d.line([(2, y), (w - 3, y)], fill=(225, 225, 225, a))
    rr(d, [0, 0, w - 1, h - 1], 4, outline=(255, 255, 255, 255))
    d.line([(4, 1), (w - 5, 1)], fill=(255, 255, 255, 255))
    return im


# ======================================================================= icones 9x9
def icon(draw_fn):
    im = Image.new("RGBA", (9, 9), (0, 0, 0, 0))
    draw_fn(ImageDraw.Draw(im), im)
    # pixel invisible tout a droite : largeur fixe de 9 (le jeu coupe les colonnes vides a droite)
    if im.getpixel((8, 8))[3] == 0:
        im.putpixel((8, 8), (255, 255, 255, 1))
    return im


def ic_splat(d, im):          # tache de peinture (teintee par l'equipe)
    W = (255, 255, 255, 255)
    rows = ["...X.....",
            ".X.XX..X.",
            "..XXXXX..",
            ".XXXXXXX.",
            "XXXXXXXX.",
            ".XXXXXXX.",
            "..XXXXX.X",
            ".X..XX...",
            "....X...."]
    for y, row in enumerate(rows):
        for x, ch in enumerate(row):
            if ch == "X":
                d.point((x, y), fill=W)
    d.point((3, 3), fill=(255, 255, 255, 160))


def ic_shield(d, im):
    d.polygon([(1, 1), (7, 1), (7, 4), (4, 8), (1, 4)], fill=(120, 205, 255, 255), outline=(225, 245, 255, 255))
    d.line([(4, 2), (4, 6)], fill=(225, 245, 255, 255))


def ic_bolt(d, im):
    d.polygon([(5, 0), (1, 5), (4, 5), (3, 8), (7, 3), (4, 3)], fill=(255, 214, 70, 255))


def ic_grenade(d, im):
    d.ellipse([1, 2, 7, 8], fill=(110, 200, 90, 255), outline=(40, 90, 35, 255))
    d.rectangle([3, 0, 5, 2], fill=(170, 175, 185, 255))
    d.point((6, 1), fill=(220, 220, 220, 255))
    d.point((3, 4), fill=(200, 255, 190, 255))


def ic_fire(d, im):
    d.polygon([(4, 0), (7, 4), (7, 7), (4, 8), (1, 7), (1, 4), (3, 3)], fill=(255, 120, 40, 255))
    d.polygon([(4, 3), (6, 6), (4, 8), (2, 6)], fill=(255, 225, 90, 255))


def ic_flag(d, im):
    d.line([(1, 0), (1, 8)], fill=(210, 210, 210, 255))
    d.polygon([(2, 0), (7, 2), (2, 4)], fill=(255, 255, 255, 255))


def ic_bomb(d, im):
    d.ellipse([0, 2, 6, 8], fill=(40, 40, 46, 255), outline=(90, 90, 100, 255))
    d.line([(5, 2), (7, 0)], fill=(200, 170, 120, 255))
    d.point((8, 0), fill=(255, 200, 60, 255))
    d.point((2, 4), fill=(140, 140, 150, 255))


def ic_crown(d, im):
    d.polygon([(0, 2), (2, 5), (4, 1), (6, 5), (8, 2), (8, 7), (0, 7)], fill=(255, 205, 60, 255))
    d.line([(0, 7), (8, 7)], fill=(200, 140, 20, 255))


def ic_skull(d, im):
    d.ellipse([1, 0, 7, 6], fill=(235, 235, 235, 255))
    d.rectangle([2, 5, 6, 8], fill=(235, 235, 235, 255))
    d.point((3, 3), fill=(30, 30, 30, 255))
    d.point((5, 3), fill=(30, 30, 30, 255))
    d.point((3, 7), fill=(30, 30, 30, 255))
    d.point((5, 7), fill=(30, 30, 30, 255))


def ic_target(d, im):          # visee
    d.ellipse([0, 0, 8, 8], outline=(255, 255, 255, 255))
    d.point((4, 4), fill=(255, 80, 80, 255))
    for p in [(4, 1), (4, 7), (1, 4), (7, 4)]:
        d.point(p, fill=(255, 255, 255, 255))


def ic_clock(d, im):
    d.ellipse([0, 0, 8, 8], fill=(30, 36, 48, 255), outline=(230, 230, 230, 255))
    d.line([(4, 4), (4, 1)], fill=(255, 255, 255, 255))
    d.line([(4, 4), (6, 5)], fill=(255, 255, 255, 255))


def ic_dot(d, im):              # puce (teintee)
    d.ellipse([2, 2, 6, 6], fill=(255, 255, 255, 255))


ICONS = [  # (nom, caractere, fonction) : memes caracteres dans PaintballHud.java
    ("splat", "", ic_splat), ("shield", "", ic_shield), ("bolt", "", ic_bolt),
    ("grenade", "", ic_grenade), ("fire", "", ic_fire), ("flag", "", ic_flag),
    ("bomb", "", ic_bomb), ("crown", "", ic_crown), ("skull", "", ic_skull),
    ("target", "", ic_target), ("clock", "", ic_clock), ("dot", "", ic_dot),
]


# ======================================================================= hitmarker (48x48 -> 24 unites)
def hitmarker():
    s = 48
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    c = s / 2 - 0.5
    for ang in (45, 135, 225, 315):
        a = math.radians(ang)
        x1, y1 = c + math.cos(a) * 5, c + math.sin(a) * 5
        x2, y2 = c + math.cos(a) * 11, c + math.sin(a) * 11
        d.line([(x1, y1), (x2, y2)], fill=(0, 0, 0, 160), width=4)
    for ang in (45, 135, 225, 315):
        a = math.radians(ang)
        x1, y1 = c + math.cos(a) * 5.5, c + math.sin(a) * 5.5
        x2, y2 = c + math.cos(a) * 10.5, c + math.sin(a) * 10.5
        d.line([(x1, y1), (x2, y2)], fill=(255, 255, 255, 255), width=2)
    im.putpixel((s - 1, s - 1), (255, 255, 255, 1))
    return im


# ======================================================================= polices
def ascii_rows():
    rows = ["\u0000" * 16, "\u0000" * 16, " !\"#$%&'()*+,-./", "0123456789:;<=>?", "@ABCDEFGHIJKLMNO",
            "PQRSTUVWXYZ[\\]^_", "`abcdefghijklmno", "pqrstuvwxyz{|}~\u0000"]
    return rows + ["\u0000" * 16] * 8


def fonts():
    save(timer_panel(), "kiwilando", "textures", "font", "hud", "timer.png")
    save(team_panel(), "kiwilando", "textures", "font", "hud", "team.png")
    for name, _ch, fn in ICONS:
        save(icon(fn), "kiwilando", "textures", "font", "hud", "icon_" + name + ".png")
    save(hitmarker(), "kiwilando", "textures", "font", "hud", "hitmarker.png")

    def icons(asc):
        return [{"type": "bitmap", "file": "kiwilando:font/hud/icon_%s.png" % n, "ascent": asc, "height": 9, "chars": [ch]}
                for n, ch, _f in ICONS]

    base = [
        {"type": "bitmap", "file": "kiwilando:font/hud/timer.png", "ascent": 10, "height": 16, "chars": [""]},
        {"type": "bitmap", "file": "kiwilando:font/hud/team.png", "ascent": 10, "height": 16, "chars": [""]},
    ] + icons(8)
    jdump({"providers": base}, "kiwilando", "font", "hud.json")
    for n in HUD_Y:
        prov = [{"type": "bitmap", "file": "minecraft:font/ascii.png", "ascent": 7 - n, "height": 8, "chars": ascii_rows()}]
        prov += icons(8 - n)
        jdump({"providers": prov}, "kiwilando", "font", "hud_y%d.json" % n)
    # sous-titre (echelle x2, tire a y=5) : glyphe de 24 unites, ascent 24 -> centre pile sur le viseur
    jdump({"providers": [{"type": "bitmap", "file": "kiwilando:font/hud/hitmarker.png", "ascent": 24, "height": 24,
                          "chars": [""]}]}, "kiwilando", "font", "hud_center.json")


def invisible_pink_bossbar():
    for n in ("pink_background", "pink_progress"):
        save(Image.new("RGBA", (182, 5), (0, 0, 0, 0)), "minecraft", "textures", "gui", "sprites", "boss_bar", n + ".png")


# ======================================================================= masque de paintball
def mask_textures():
    W, H = 64, 32
    base = Image.new("RGBA", (W, H), (0, 0, 0, 0))   # couche teintee (couleur d'equipe)
    over = Image.new("RGBA", (W, H), (0, 0, 0, 0))   # couche fixe (visiere, sangles, grilles)
    b, o = ImageDraw.Draw(base), ImageDraw.Draw(over)
    # zones du casque (tete 8x8x8) : dessus (8,0) dessous (16,0) droite (0,8) face (8,8) gauche (16,8) dos (24,8)
    shell = (235, 235, 235, 255)
    shade = (190, 190, 190, 255)
    # dessus : coque + bandeau
    b.rectangle([8, 0, 15, 7], fill=shell)
    b.line([(8, 7), (15, 7)], fill=shade)
    o.rectangle([11, 0, 12, 7], fill=(35, 38, 44, 255))
    # face : coque autour, visiere, grille de respiration
    b.rectangle([8, 8, 15, 15], fill=shell)
    b.line([(8, 15), (15, 15)], fill=shade)
    o.rectangle([8, 10, 15, 12], fill=(40, 46, 58, 255))              # cadre visiere
    o.rectangle([9, 10, 14, 11], fill=(70, 160, 220, 235))            # verre
    o.point((10, 10), fill=(210, 245, 255, 255))                      # reflet
    o.point((11, 10), fill=(160, 220, 250, 255))
    for x in (10, 12):
        o.point((x, 14), fill=(30, 32, 36, 255))                       # grille
    o.line([(9, 13), (14, 13)], fill=(60, 64, 72, 255))
    # cotes : coque + vis de visiere + sangle
    for x0 in (0, 16):
        b.rectangle([x0, 8, x0 + 7, 15], fill=shell)
        b.line([(x0, 15), (x0 + 7, 15)], fill=shade)
        o.rectangle([x0, 10, x0 + 7, 11], fill=(35, 38, 44, 255))     # sangle
        o.point((x0 + 3 if x0 == 16 else x0 + 4, 11), fill=(170, 175, 185, 255))
    # dos : sangle elastique
    o.rectangle([24, 10, 31, 11], fill=(35, 38, 44, 255))
    o.line([(26, 10), (29, 10)], fill=(80, 85, 95, 255))
    save(base, "kiwilando", "textures", "entity", "equipment", "humanoid", "paintball_mask.png")
    save(over, "kiwilando", "textures", "entity", "equipment", "humanoid", "paintball_mask_overlay.png")
    jdump({"layers": {"humanoid": [
        {"texture": "kiwilando:paintball_mask", "dyeable": {"color_when_undyed": -1}},
        {"texture": "kiwilando:paintball_mask_overlay"}]}}, "kiwilando", "equipment", "paintball_mask.json")

    # icone (vue de face) : couche 0 teintee + couche 1 fixe
    i0 = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    i1 = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    a, c = ImageDraw.Draw(i0), ImageDraw.Draw(i1)
    a.rounded_rectangle([2, 2, 13, 14], radius=4, fill=(240, 240, 240, 255))
    a.line([(3, 13), (12, 13)], fill=(185, 185, 185, 255))
    c.rounded_rectangle([2, 5, 13, 8], radius=1, fill=(40, 46, 58, 255))
    c.rectangle([3, 6, 12, 7], fill=(70, 160, 220, 255))
    c.point((4, 6), fill=(220, 248, 255, 255))
    c.point((5, 6), fill=(170, 225, 250, 255))
    for x in (6, 9):
        c.rectangle([x, 10, x + 1, 11], fill=(35, 38, 44, 255))
    c.line([(1, 6), (1, 7)], fill=(35, 38, 44, 255))
    c.line([(14, 6), (14, 7)], fill=(35, 38, 44, 255))
    save(i0, "kiwilando", "textures", "item", "paintball", "mask.png")
    save(i1, "kiwilando", "textures", "item", "paintball", "mask_overlay.png")
    jdump({"parent": "minecraft:item/generated",
           "textures": {"layer0": "kiwilando:item/paintball/mask", "layer1": "kiwilando:item/paintball/mask_overlay"}},
          "kiwilando", "models", "item", "paintball", "mask.json")
    jdump({"model": {"type": "minecraft:model", "model": "kiwilando:item/paintball/mask",
                     "tints": [{"type": "minecraft:dye", "default": -1}]}},
          "kiwilando", "items", "paintball", "mask.json")


# ======================================================================= grenade de peinture
def grenade():
    g0 = Image.new("RGBA", (16, 16), (0, 0, 0, 0))   # corps (teinte equipe)
    g1 = Image.new("RGBA", (16, 16), (0, 0, 0, 0))   # goupille, bande, reflet
    a, c = ImageDraw.Draw(g0), ImageDraw.Draw(g1)
    a.ellipse([3, 4, 12, 14], fill=(245, 245, 245, 255))
    a.ellipse([4, 9, 12, 14], fill=(200, 200, 200, 255))
    a.ellipse([4, 5, 11, 12], fill=(240, 240, 240, 255))
    c.rectangle([6, 2, 9, 4], fill=(150, 156, 168, 255))             # col
    c.line([(6, 2), (9, 2)], fill=(200, 205, 215, 255))
    c.ellipse([9, 0, 12, 3], outline=(205, 210, 220, 255))          # anneau
    c.line([(3, 9), (12, 9)], fill=(30, 33, 40, 200))               # bande
    c.point((5, 6), fill=(255, 255, 255, 230))                       # reflet
    c.point((6, 6), fill=(255, 255, 255, 140))
    c.point((5, 7), fill=(255, 255, 255, 140))
    save(g0, "kiwilando", "textures", "item", "paintball", "grenade.png")
    save(g1, "kiwilando", "textures", "item", "paintball", "grenade_overlay.png")
    jdump({"parent": "minecraft:item/generated",
           "textures": {"layer0": "kiwilando:item/paintball/grenade", "layer1": "kiwilando:item/paintball/grenade_overlay"}},
          "kiwilando", "models", "item", "paintball", "grenade.json")
    jdump({"model": {"type": "minecraft:model", "model": "kiwilando:item/paintball/grenade",
                     "tints": [{"type": "minecraft:custom_model_data", "index": 0, "default": -1}]}},
          "kiwilando", "items", "paintball", "grenade.json")


# ======================================================================= visiere et lunette (plein ecran)
def overlays():
    # l'image est etiree sur tout l'ecran : dessinee pour un ecran 16:9 (cercle a l'ecran, ellipse dans l'image)
    S = 512
    ratio = 9 / 16
    # visiere : coins sombres tres legers + bord de masque
    v = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    px = v.load()
    for y in range(S):
        for x in range(S):
            nx, ny = (x / S - 0.5) * 2, (y / S - 0.5) * 2
            r = math.sqrt((nx * 1.0) ** 2 + (ny * 1.08) ** 2)
            a = max(0.0, (r - 0.92) / 0.5)
            px[x, y] = (8, 10, 14, int(min(1.0, a) ** 1.6 * 150))
    vd = ImageDraw.Draw(v)
    vd.rectangle([0, S - 10, S, S], fill=(10, 12, 16, 120))          # bas du masque
    save(v.filter(ImageFilter.GaussianBlur(2)), "kiwilando", "textures", "misc", "paintball_mask.png")

    # lunette : noir autour, cercle net, reticule fin avec point central
    s = Image.new("RGBA", (S, S), (6, 7, 9, 255))
    m = Image.new("L", (S, S), 0)
    rad_y = S * 0.42
    rad_x = rad_y * ratio
    ImageDraw.Draw(m).ellipse([S / 2 - rad_x, S / 2 - rad_y, S / 2 + rad_x, S / 2 + rad_y], fill=255)
    m = m.filter(ImageFilter.GaussianBlur(1.5))
    hole = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    s.paste(hole, (0, 0), m)
    d = ImageDraw.Draw(s)
    d.ellipse([S / 2 - rad_x, S / 2 - rad_y, S / 2 + rad_x, S / 2 + rad_y], outline=(20, 22, 26, 255), width=3)
    col = (20, 22, 26, 220)
    gap = 10
    d.line([(S / 2, S / 2 - rad_y), (S / 2, S / 2 - gap)], fill=col, width=1)
    d.line([(S / 2, S / 2 + gap), (S / 2, S / 2 + rad_y)], fill=col, width=1)
    d.line([(S / 2 - rad_x, S / 2), (S / 2 - gap * ratio, S / 2)], fill=col, width=1)
    d.line([(S / 2 + gap * ratio, S / 2), (S / 2 + rad_x, S / 2)], fill=col, width=1)
    for k in range(1, 5):                                            # graduations
        yy = S / 2 + k * rad_y / 5
        d.line([(S / 2 - 6 * ratio, yy), (S / 2 + 6 * ratio, yy)], fill=col)
    d.ellipse([S / 2 - 2 * ratio, S / 2 - 2, S / 2 + 2 * ratio, S / 2 + 2], fill=(255, 70, 70, 230))
    save(s, "kiwilando", "textures", "misc", "paintball_scope.png")


def main():
    fonts()
    invisible_pink_bossbar()
    mask_textures()
    grenade()
    overlays()
    print("HUD paintball genere dans", OUT)


if __name__ == "__main__":
    main()
