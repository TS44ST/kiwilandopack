#!/usr/bin/env python3
"""
Genere le pack de textures KiwilandoAdmin :
 - badges de grade (police bitmap kiwilando:badges, rendu 2x pour plus de finesse)
 - icones 32x32 des menus du staff (item_model kiwilando:admin/<nom>)
Tout est dessine par code : formes -> eclairage haut-gauche -> contour sombre -> reflets.
Usage (depuis le dossier du projet) : python3 resource-pack-src/generer_pack_admin.py resource-pack
 -> redessine la partie admin dans resource-pack/ et cree Kiwilando-Pack.zip (pack complet)
"""
import json, math, os, sys, zipfile
from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "pack"
S = 32  # taille des icones

# ----------------------------------------------------------------- outils couleur
def hexc(h, a=255):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)

def mix(c1, c2, t):
    return tuple(int(round(c1[i] + (c2[i] - c1[i]) * t)) for i in range(3)) + (255,)

def shade(c, f):
    if f >= 1:
        return mix(c, (255, 255, 255), min(1, f - 1))
    return mix((0, 0, 0), c, max(0, f))

# ----------------------------------------------------------------- moteur de "pixel art eclaire"
class Icon:
    def __init__(self, size=S):
        self.size = size
        self.img = Image.new("RGBA", (size, size), (0, 0, 0, 0))

    def mask(self, fn):
        m = Image.new("L", (self.size, self.size), 0)
        fn(ImageDraw.Draw(m))
        return m

    def layer(self, fn, color, light=0.35, outline=0.35, gloss=True, bevel=True, grad="tl"):
        """Dessine une forme : degrade d'eclairage, biseau, contour et reflet."""
        m = self.mask(fn)
        mp = m.load()
        n = self.size
        px = self.img.load()
        base = hexc(color) if isinstance(color, str) else color
        inside = lambda x, y: 0 <= x < n and 0 <= y < n and mp[x, y] > 127
        pts = [(x, y) for y in range(n) for x in range(n) if inside(x, y)]
        if not pts:
            return m
        minx = min(p[0] for p in pts); maxx = max(p[0] for p in pts)
        miny = min(p[1] for p in pts); maxy = max(p[1] for p in pts)
        w = max(1, maxx - minx); h = max(1, maxy - miny)
        for x, y in pts:
            if grad == "tl":
                t = ((x - minx) / w * 0.45 + (y - miny) / h * 0.55)
            elif grad == "v":
                t = (y - miny) / h
            else:
                t = (x - minx) / w
            f = 1 + light - t * light * 2.2
            c = shade(base, f)
            if bevel:
                # biseau : bord haut/gauche clair, bas/droite sombre
                if not inside(x - 1, y) or not inside(x, y - 1):
                    c = shade(base, 1.35)
                elif not inside(x + 1, y) or not inside(x, y + 1):
                    c = shade(base, 0.62)
            px[x, y] = c
        # contour sombre exterieur
        if outline:
            oc = shade(base, outline)
            for y in range(n):
                for x in range(n):
                    if inside(x, y):
                        continue
                    if any(inside(x + dx, y + dy) for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1))):
                        if px[x, y][3] == 0 or True:
                            px[x, y] = oc
        # reflet brillant
        if gloss:
            gx, gy = minx + max(1, w // 5), miny + max(1, h // 5)
            for (dx, dy) in ((0, 0), (1, 0), (0, 1)):
                if inside(gx + dx, gy + dy):
                    px[gx + dx, gy + dy] = (255, 255, 255, 235)
        return m

    def pixels(self, coords, color):
        px = self.img.load()
        c = hexc(color) if isinstance(color, str) else color
        for x, y in coords:
            if 0 <= x < self.size and 0 <= y < self.size:
                px[x, y] = c

    def line(self, pts, color, width=1):
        d = ImageDraw.Draw(self.img)
        d.line(pts, fill=hexc(color) if isinstance(color, str) else color, width=width)

    def shadow(self):
        """Ombre portee douce en bas a droite (rend les icones plus lisibles sur fond gris)."""
        sh = Image.new("RGBA", self.img.size, (0, 0, 0, 0))
        a = self.img.split()[3]
        spx = sh.load(); apx = a.load()
        for y in range(self.size):
            for x in range(self.size):
                if apx[x, y] > 0 and x + 1 < self.size and y + 1 < self.size:
                    spx[x + 1, y + 1] = (0, 0, 0, 90)
        sh.alpha_composite(self.img)
        self.img = sh
        return self

# ----------------------------------------------------------------- icones
def ellipse(b):
    return lambda d: d.ellipse(b, fill=255)

def rect(b, r=0):
    return lambda d: d.rounded_rectangle(b, radius=r, fill=255) if r else d.rectangle(b, fill=255)

def poly(p):
    return lambda d: d.polygon(p, fill=255)

ICONS = {}

def icon(name):
    def deco(fn):
        ICONS[name] = fn
        return fn
    return deco

@icon("ban")
def _ban(i):
    # marteau de justice : manche bois + tete metal
    i.layer(poly([(6, 27), (9, 30), (21, 18), (18, 15)]), "#8a5a2b", light=0.3)
    i.layer(poly([(13, 9), (20, 2), (30, 12), (23, 19)]), "#9aa3ad", light=0.45)
    i.layer(poly([(12, 10), (14, 8), (24, 18), (22, 20)]), "#5d6670", light=0.2, gloss=False)
    i.layer(rect((2, 27, 13, 30), 1), "#6b4423", light=0.3, gloss=False)

@icon("ipban")
def _ipban(i):
    _ban(i)
    i.layer(ellipse((18, 18, 30, 30)), "#d9363e", light=0.3)
    i.layer(rect((20, 23, 28, 25)), "#ffffff", light=0, outline=0, bevel=False, gloss=False)

@icon("mute")
def _mute(i):
    i.layer(rect((4, 11, 11, 21), 1), "#9aa3ad")
    i.layer(poly([(10, 11), (18, 4), (18, 28), (10, 21)]), "#c2c9d1")
    i.line([(21, 10), (29, 22)], "#e5484d", 3)
    i.line([(29, 10), (21, 22)], "#e5484d", 3)

@icon("kick")
def _kick(i):
    i.layer(poly([(8, 3), (16, 3), (16, 18), (27, 20), (29, 26), (6, 26)]), "#8b5a35", light=0.4)
    i.layer(rect((6, 25, 29, 28), 1), "#3d2a1d", light=0.2, gloss=False)
    i.layer(rect((8, 3, 16, 7), 1), "#a06a40", light=0.3, gloss=False)
    i.pixels([(10, 10), (12, 10), (14, 10), (10, 13), (12, 13), (14, 13)], "#e8d3b0")

@icon("warn")
def _warn(i):
    i.layer(poly([(16, 2), (30, 28), (2, 28)]), "#f2c94c", light=0.45)
    i.layer(rect((14, 10, 17, 20), 1), "#2b2b2b", light=0.1, outline=0, gloss=False, bevel=False)
    i.layer(rect((14, 22, 17, 25), 1), "#2b2b2b", light=0.1, outline=0, gloss=False, bevel=False)

@icon("anticheat")
def _ac(i):
    i.layer(poly([(16, 2), (28, 6), (27, 18), (16, 30), (5, 18), (4, 6)]), "#3b82f6", light=0.45)
    i.layer(poly([(16, 5), (25, 8), (24, 17), (16, 26)]), "#1e5fd0", light=0.25, outline=0, gloss=False)
    i.line([(10, 16), (14, 20), (22, 11)], "#7ee787", 3)

@icon("guard")
def _guard(i):
    i.layer(rect((7, 14, 25, 29), 3), "#e0a43a", light=0.45)
    i.layer(lambda d: d.arc((9, 3, 23, 21), 180, 360, fill=255, width=4), "#9aa3ad", light=0.3)
    i.layer(ellipse((14, 18, 18, 22)), "#3a2a12", light=0, outline=0, gloss=False, bevel=False)
    i.layer(rect((15, 21, 17, 26)), "#3a2a12", light=0, outline=0, gloss=False, bevel=False)

@icon("note")
def _note(i):
    i.layer(rect((6, 3, 26, 29), 2), "#efe3c2", light=0.25)
    for y in (9, 13, 17, 21):
        i.line([(10, y), (22, y)], "#9c8b66", 1)
    i.layer(poly([(20, 20), (29, 11), (31, 13), (22, 22)]), "#f2994a", light=0.3)

@icon("check")
def _check(i):
    i.layer(ellipse((3, 3, 21, 21)), "#7aa7c7", light=0.5)
    i.layer(ellipse((6, 6, 18, 18)), "#cde8ff", light=0.35, outline=0)
    i.layer(poly([(18, 20), (21, 17), (30, 26), (27, 29)]), "#6b4423", light=0.3)

@icon("rank")
def _rank(i):
    i.layer(poly([(3, 24), (4, 9), (10, 16), (16, 5), (22, 16), (28, 9), (29, 24)]), "#f5c542", light=0.5)
    i.layer(rect((3, 23, 29, 28), 1), "#d49a1a", light=0.35, gloss=False)
    i.layer(ellipse((14, 15, 19, 20)), "#e5484d", light=0.4)
    i.layer(ellipse((6, 18, 10, 22)), "#3b82f6", light=0.4, gloss=False)
    i.layer(ellipse((22, 18, 26, 22)), "#7ee787", light=0.4, gloss=False)

@icon("players")
def _players(i):
    i.layer(ellipse((17, 4, 27, 14)), "#c58c5c", light=0.35)
    i.layer(rect((15, 15, 29, 28), 4), "#3b82f6", light=0.35)
    i.layer(ellipse((5, 7, 15, 17)), "#e0b088", light=0.35)
    i.layer(rect((3, 18, 17, 30), 4), "#2ea043", light=0.35)

def arrow(i, left):
    pts = [(4, 16), (16, 4), (16, 11), (28, 11), (28, 21), (16, 21), (16, 28)]
    if not left:
        pts = [(S - 1 - x, y) for x, y in pts]
    i.layer(poly(pts), "#7ee787", light=0.45)

@icon("previous")
def _prev(i):
    arrow(i, True)

@icon("next")
def _next(i):
    arrow(i, False)

@icon("back")
def _back(i):
    i.layer(lambda d: d.arc((5, 6, 27, 28), 200, 90, fill=255, width=5), "#f2c94c", light=0.4)
    i.layer(poly([(1, 13), (11, 5), (11, 20)]), "#f2c94c", light=0.4)

@icon("close")
def _close(i):
    i.layer(ellipse((2, 2, 29, 29)), "#e5484d", light=0.45)
    i.line([(10, 10), (21, 21)], "#ffffff", 3)
    i.line([(21, 10), (10, 21)], "#ffffff", 3)

@icon("reload")
def _reload(i):
    i.layer(lambda d: d.arc((4, 4, 27, 27), 30, 300, fill=255, width=5), "#56d4dd", light=0.45)
    i.layer(poly([(19, 2), (29, 9), (19, 14)]), "#56d4dd", light=0.4)

@icon("server")
def _server(i):
    for k, y in enumerate((3, 12, 21)):
        i.layer(rect((4, y, 27, y + 7), 2), "#4b5563", light=0.4, gloss=(k == 0))
        i.pixels([(8, y + 3), (9, y + 3)], "#7ee787")
        i.pixels([(12, y + 3)], "#f2c94c")
        i.line([(17, y + 3), (24, y + 3)], "#1f2937", 1)

@icon("modules")
def _modules(i):
    teeth = []
    for k in range(8):
        a = k * math.pi / 4
        cx, cy = 16 + math.cos(a) * 12, 16 + math.sin(a) * 12
        teeth.append((cx, cy))
    def gear(d):
        d.ellipse((6, 6, 26, 26), fill=255)
        for cx, cy in teeth:
            d.rectangle((cx - 3, cy - 3, cx + 3, cy + 3), fill=255)
    i.layer(gear, "#9aa3ad", light=0.45)
    i.layer(ellipse((12, 12, 20, 20)), "#2b313b", light=0.1, outline=0, gloss=False)

@icon("toggle_on")
def _ton(i):
    i.layer(rect((2, 9, 29, 23), 7), "#2ea043", light=0.4)
    i.layer(ellipse((16, 10, 28, 22)), "#f5f7fa", light=0.3)

@icon("toggle_off")
def _toff(i):
    i.layer(rect((2, 9, 29, 23), 7), "#6b7280", light=0.4)
    i.layer(ellipse((3, 10, 15, 22)), "#f5f7fa", light=0.3)

@icon("ac_movement")
def _mov(i):
    i.layer(poly([(4, 28), (8, 16), (16, 6), (27, 3), (24, 12), (16, 20), (9, 24)]), "#e9eef5", light=0.4)
    for k in range(4):
        i.line([(10 + k * 4, 22 - k * 4), (16 + k * 3, 18 - k * 4)], "#9aa7b8", 1)
    i.line([(4, 28), (13, 19)], "#7d6a55", 1)

@icon("ac_combat")
def _combat(i):
    def sword(flip):
        f = (lambda pts: [(S - 1 - x, y) for x, y in pts]) if flip else (lambda pts: pts)
        # lame longue et fine avec pointe
        i.layer(poly(f([(2, 2), (6, 3), (22, 19), (19, 22), (3, 6)])), "#dfe6ee", light=0.5)
        i.line(f([(4, 4), (20, 20)]), "#ffffff", 1)
        # garde
        i.layer(poly(f([(16, 24), (24, 16), (26, 18), (18, 26)])), "#d4a017", light=0.4, gloss=False)
        # poignee + pommeau
        i.layer(poly(f([(21, 23), (23, 21), (27, 25), (25, 27)])), "#6b3f1f", light=0.3, gloss=False)
        i.layer(ellipse(tuple(f([(26, 26)])[0]) + tuple(f([(29, 29)])[0]) if not flip else (2, 26, 5, 29)), "#d4a017", light=0.3, gloss=False)
    sword(False)
    sword(True)

@icon("ac_block")
def _block(i):
    i.layer(poly([(16, 3), (29, 9), (16, 15), (3, 9)]), "#8bc34a", light=0.3)
    i.layer(poly([(3, 9), (16, 15), (16, 29), (3, 23)]), "#8d6e4f", light=0.2)
    i.layer(poly([(16, 15), (29, 9), (29, 23), (16, 29)]), "#6d543c", light=0.15, gloss=False)

@icon("ac_inventory")
def _inv(i):
    i.layer(rect((3, 8, 28, 27), 2), "#a0703c", light=0.4)
    i.layer(rect((3, 8, 28, 14), 2), "#b9824a", light=0.35, gloss=False)
    i.layer(rect((14, 12, 17, 17)), "#d6d9de", light=0.3, gloss=False)
    i.line([(3, 15), (28, 15)], "#5b3d1f", 1)

@icon("ac_client")
def _client(i):
    i.layer(rect((2, 4, 29, 22), 2), "#374151", light=0.35)
    i.layer(rect((5, 7, 26, 19), 1), "#0ea5e9", light=0.45, outline=0)
    i.layer(rect((12, 23, 19, 27)), "#4b5563", light=0.2, gloss=False)
    i.layer(rect((7, 27, 24, 29), 1), "#6b7280", light=0.2, gloss=False)
    i.line([(8, 10), (12, 13), (8, 16)], "#e0f2fe", 1)

@icon("chat")
def _chat(i):
    i.layer(lambda d: (d.rounded_rectangle((2, 4, 29, 21), 6, fill=255), d.polygon([(8, 20), (8, 28), (16, 20)], fill=255)), "#5865f2", light=0.4)
    for x in (9, 15, 21):
        i.layer(ellipse((x, 11, x + 3, 14)), "#ffffff", light=0.1, outline=0, gloss=False, bevel=False)

@icon("discord")
def _discord(i):
    # cloche de notification (generique)
    i.layer(lambda d: (d.pieslice((6, 4, 26, 26), 180, 360, fill=255), d.rectangle((6, 14, 26, 23), fill=255)), "#f2c94c", light=0.45)
    i.layer(rect((3, 22, 29, 26), 2), "#d9a521", light=0.3, gloss=False)
    i.layer(ellipse((13, 25, 19, 31)), "#b8860b", light=0.3, gloss=False)
    i.layer(ellipse((14, 1, 18, 5)), "#d9a521", light=0.3, gloss=False)

@icon("panel")
def _panel(i):
    i.layer(rect((2, 4, 29, 27), 2), "#1f2937", light=0.3)
    i.layer(rect((2, 4, 29, 9), 2), "#374151", light=0.3, gloss=False)
    i.pixels([(5, 6), (7, 6), (9, 6)], "#e5484d")
    i.pixels([(7, 6)], "#f2c94c"); i.pixels([(9, 6)], "#2ea043")
    pts = [(5, 23), (9, 19), (13, 21), (18, 14), (22, 17), (26, 11)]
    i.line(pts, "#7ee787", 2)

@icon("sub")
def _sub(i):
    # coeur violet avec etoile (abonnes)
    i.layer(lambda d: (d.ellipse((3, 5, 17, 19), fill=255), d.ellipse((15, 5, 29, 19), fill=255),
                       d.polygon([(4, 15), (16, 29), (28, 15)], fill=255)), "#a970ff", light=0.5)
    star = [(16, 8), (18, 13), (23, 13), (19, 16), (21, 21), (16, 18), (11, 21), (13, 16), (9, 13), (14, 13)]
    i.layer(poly(star), "#ffe066", light=0.35, gloss=False)

@icon("pack")
def _pack(i):
    i.layer(lambda d: (d.ellipse((2, 4, 29, 28), fill=255)), "#d9b38c", light=0.35)
    i.layer(ellipse((16, 17, 23, 24)), (0, 0, 0, 0) if False else "#a27b55", light=0.1, outline=0, gloss=False)
    for (x, y, c) in ((7, 9, "#e5484d"), (13, 7, "#f2c94c"), (19, 8, "#2ea043"), (7, 16, "#3b82f6"), (23, 13, "#bc8cff")):
        i.layer(ellipse((x, y, x + 4, y + 4)), c, light=0.4, gloss=False)

# ----------------------------------------------------------------- badges (police)
FONT = {  # police pixel 3x5 (majuscules, chiffres, +)
    "A": ["010", "101", "111", "101", "101"], "B": ["110", "101", "110", "101", "110"], "C": ["011", "100", "100", "100", "011"],
    "D": ["110", "101", "101", "101", "110"], "E": ["111", "100", "110", "100", "111"], "F": ["111", "100", "110", "100", "100"],
    "G": ["011", "100", "101", "101", "011"], "H": ["101", "101", "111", "101", "101"], "I": ["111", "010", "010", "010", "111"],
    "J": ["001", "001", "001", "101", "010"], "K": ["101", "101", "110", "101", "101"], "L": ["100", "100", "100", "100", "111"],
    "M": ["10001", "11011", "10101", "10001", "10001"], "N": ["1001", "1101", "1011", "1001", "1001"], "O": ["010", "101", "101", "101", "010"],
    "P": ["110", "101", "110", "100", "100"], "R": ["110", "101", "110", "101", "101"], "S": ["011", "100", "010", "001", "110"],
    "T": ["111", "010", "010", "010", "010"], "U": ["101", "101", "101", "101", "111"], "V": ["101", "101", "101", "101", "010"],
    "W": ["10001", "10001", "10101", "11011", "10001"], "Y": ["101", "101", "010", "010", "010"], "+": ["000", "010", "111", "010", "000"],
    " ": ["0", "0", "0", "0", "0"],
}

BADGES = [
    # id, texte, couleur haut, couleur bas, symbole, caractere de la police
    ("staff", "STAFF", "#ff6b6b", "#c92a2a", "shield", 0xE100),
    ("sub", "SUB", "#bf94ff", "#6b2fd6", "heart", 0xE10A),
    ("vip", "VIP", "#69db7c", "#2b8a3e", "emerald", 0xE108),
    ("membre", "MEMBRE", "#ced4da", "#868e96", "leaf", 0xE109),
]

SYMBOLS = {  # 7x7
    "crown": ["0000000", "1001001", "1101011", "1111111", "1111111", "0111110", "0000000"],
    "star": ["0001000", "0011100", "1111111", "0111110", "0011100", "0110110", "0100010"],
    "code": ["0000000", "0100010", "1000001", "1001001", "1000001", "0100010", "0000000"],
    "shield": ["1111111", "1111111", "1111111", "1111111", "0111110", "0011100", "0001000"],
    "heart": ["0000000", "0110110", "1111111", "1111111", "0111110", "0011100", "0001000"],
    "brick": ["1110111", "0000000", "0111011", "0000000", "1110111", "0000000", "0111011"],
    "play": ["0100000", "0110000", "0111000", "0111100", "0111000", "0110000", "0100000"],
    "diamond": ["0001000", "0011100", "0111110", "1111111", "0111110", "0011100", "0001000"],
    "emerald": ["0011100", "0111110", "1111111", "1111111", "1111111", "0111110", "0011100"],
    "leaf": ["0000011", "0001111", "0011111", "0111110", "0111100", "1011000", "1000000"],
}

def text_width(t):
    return sum(len(FONT[c][0]) + 1 for c in t) - 1

def badge(text, top, bottom, sym):
    """Pastille 2x : hauteur 18 px (affichee 9 px en jeu), degrade, contour, reflet, symbole + texte."""
    H = 18
    tw = text_width(text) * 2
    W = 4 + 14 + 3 + tw + 6
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    px = img.load()
    t, b = hexc(top), hexc(bottom)
    r = 6
    def inside(x, y):
        if x < 0 or y < 0 or x >= W or y >= H:
            return False
        cx = min(max(x, r), W - 1 - r)
        cy = min(max(y, r), H - 1 - r)
        return (x - cx) ** 2 + (y - cy) ** 2 <= r * r + 0.5
    for y in range(H):
        for x in range(W):
            if not inside(x, y):
                continue
            c = mix(t, b, y / (H - 1))
            if not inside(x, y - 1) or not inside(x - 1, y) or not inside(x + 1, y) or not inside(x, y + 1):
                c = shade(b, 0.45)  # contour
            elif y < 7:
                c = mix(c, (255, 255, 255), 0.18 * (1 - y / 7))  # reflet haut
            px[x, y] = c
    # liseré clair interieur
    for x in range(r, W - r):
        if inside(x, 1):
            px[x, 1] = mix(hexc(top), (255, 255, 255), 0.55)
    # symbole (7x7 en 2x) avec ombre
    sx, sy = 4, 2
    rows = SYMBOLS[sym]
    for yy, row in enumerate(rows):
        for xx, ch in enumerate(row):
            if ch == "1":
                for dx in range(2):
                    for dy in range(2):
                        X, Y = sx + xx * 2 + dx, sy + yy * 2 + dy
                        if X + 1 < W and Y + 1 < H:
                            px[X + 1, Y + 1] = shade(b, 0.35)
        for xx, ch in enumerate(row):
            pass
    for yy, row in enumerate(rows):
        for xx, ch in enumerate(row):
            if ch == "1":
                for dx in range(2):
                    for dy in range(2):
                        X, Y = sx + xx * 2 + dx, sy + yy * 2 + dy
                        px[X, Y] = (255, 255, 255, 255) if yy < 3 else (240, 244, 250, 255)
    # texte (3x5 en 2x) avec ombre portee
    x0 = sx + 14 + 3
    y0 = 4
    for pass_ in (0, 1):
        cx = x0
        for ch in text:
            g = FONT[ch]
            for yy, row in enumerate(g):
                for xx, v in enumerate(row):
                    if v == "1":
                        for dx in range(2):
                            for dy in range(2):
                                X = cx + xx * 2 + dx + (1 if pass_ == 0 else 0)
                                Y = y0 + yy * 2 + dy + (1 if pass_ == 0 else 0)
                                if 0 <= X < W and 0 <= Y < H:
                                    px[X, Y] = shade(b, 0.35) if pass_ == 0 else (255, 255, 255, 255)
            cx += (len(g[0]) + 1) * 2
    return img


# ----------------------------------------------------------------- fonds de menus (titre-image)
THEMES = {  # id: (accent clair, accent fonce)
    "kiwi": ("#7ee787", "#2ea043"),
    "red": ("#ff6b6b", "#c92a2a"),
    "purple": ("#c39bff", "#7b3fe4"),
    "gold": ("#ffd56b", "#e08e0b"),
}
THEME_ORDER = ["kiwi", "red", "purple", "gold"]

# Menus des jeux (police kiwilando:menu, MenuStyle.java) : meme dessin que le staff, une couleur par jeu.
# Ordre = MenuStyle.THEMES ; glyphe 0xE200 + index*2 (+1 pour 6 lignes).
GAME_THEMES = [
    ("main", "#82d246", "#3f7a1c"),
    ("paintball", "#f5a528", "#b0610a"),
    ("kart", "#46cdeb", "#16789a"),
    ("parkour", "#5ae182", "#1f8a45"),
    ("dac", "#5a96ff", "#2350b8"),
    ("backrooms", "#ebd750", "#9c8a14"),
    ("zombies", "#78be3c", "#3b6b15"),
    ("core", "#f0c846", "#a77d0c"),
]
for _gid, _l, _d in GAME_THEMES:
    THEMES["game_" + _gid] = (_l, _d)

def gui_bg(rows, theme):
    """Fond complet d'un menu coffre (176 x rows*18+114) : cadre arrondi, en-tete degrade, cases modernes."""
    W, H = 176, rows * 18 + 114
    light, dark = hexc(THEMES[theme][0]), hexc(THEMES[theme][1])
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    px = img.load()
    R = 7
    def inside(x, y, inset=0):
        x0, y0, x1, y1 = inset, inset, W - 1 - inset, H - 1 - inset
        if x < x0 or y < y0 or x > x1 or y > y1:
            return False
        r = R - inset
        cx = min(max(x, x0 + r), x1 - r)
        cy = min(max(y, y0 + r), y1 - r)
        return (x - cx) ** 2 + (y - cy) ** 2 <= r * r + 0.6
    top, bot = hexc("#232a36"), hexc("#12161d")
    for y in range(H):
        for x in range(W):
            if not inside(x, y):
                continue
            if not inside(x, y, 1):
                px[x, y] = mix(dark, (0, 0, 0), 0.25)          # contour
            elif not inside(x, y, 2):
                px[x, y] = mix(light, hexc("#232a36"), 0.55)   # liseré lumineux
            else:
                c = mix(top, bot, y / H)
                # fine trame en diagonale pour la texture
                if (x + y) % 6 == 0:
                    c = mix(c, (255, 255, 255), 0.025)
                px[x, y] = c
    # en-tete degrade (zone du titre)
    for y in range(3, 15):
        for x in range(3, W - 3):
            if inside(x, y, 2):
                t = x / W
                c = mix(mix(dark, hexc("#232a36"), 0.35), hexc("#1b212b"), min(1, t * 1.4))
                if y == 3:
                    c = mix(light, c, 0.2)
                px[x, y] = c
    d.line([(4, 15), (W - 5, 15)], fill=mix(light, hexc("#12161d"), 0.5))
    # petit kiwi a droite de l'en-tete
    cx, cy = W - 14, 9
    for yy in range(-5, 6):
        for xx in range(-5, 6):
            r2 = xx * xx + yy * yy
            if r2 <= 25:
                px[cx + xx, cy + yy] = hexc("#6b4a2b") if r2 > 18 else (hexc("#7ee787") if r2 > 5 else hexc("#f3fbe9"))
    for a in range(8):
        ang = a * math.pi / 4
        px[int(round(cx + math.cos(ang) * 3)), int(round(cy + math.sin(ang) * 3))] = (25, 25, 25, 255)
    def slot(x, y, hot=False):
        # case 18x18 : fond creux, coins arrondis, biseau interieur
        for yy in range(18):
            for xx in range(18):
                corner = (xx in (0, 17)) and (yy in (0, 17))
                if corner:
                    continue
                X, Y = x + xx, y + yy
                if xx == 0 or yy == 0:
                    c = hexc("#0a0d12")
                elif xx == 17 or yy == 17:
                    c = hexc("#2c3442")
                else:
                    c = mix(hexc("#151a22"), hexc("#0f1319"), yy / 17)
                    if hot:
                        c = mix(c, light, 0.06)
                px[X, Y] = c
    for r in range(rows):
        for c in range(9):
            slot(7 + c * 18, 17 + r * 18, hot=False)
    # separation conteneur / inventaire du joueur
    ys = 17 + rows * 18 + 4
    for x in range(10, W - 10):
        t = abs(x - W / 2) / (W / 2)
        px[x, ys] = mix(light, hexc("#1b212b"), 0.35 + t * 0.6)
    y0 = 17 + rows * 18 + 13   # cadre des cases de l'inventaire du joueur, aligne au pixel sur le vanilla
    for r in range(3):
        for c in range(9):
            slot(7 + c * 18, y0 + r * 18)
    for c in range(9):
        slot(7 + c * 18, y0 + 3 * 18 + 4, hot=True)
    return img


HUB_BUTTONS = [10, 12, 14, 16, 19, 21, 23, 25, 38, 40, 42]
HUB_PLAYERS = list(range(28, 35))

def gui_hub():
    """Menu principal /kadmin : banniere, cartes lumineuses pour les boutons, plateau pour les joueurs."""
    rows = 5
    img = gui_bg(rows, "kiwi")
    px = img.load()
    light, dark = hexc("#7ee787"), hexc("#2ea043")
    panel_top, panel_bot = hexc("#1d232d"), hexc("#151a22")
    # efface les cases du conteneur -> panneau lisse
    for y in range(17, 17 + rows * 18):
        for x in range(7, 7 + 9 * 18):
            c = mix(panel_top, panel_bot, (y - 17) / (rows * 18))
            if (x * 3 + y) % 11 == 0:
                c = mix(c, light, 0.05)
            px[x, y] = c
    # banniere "ADMINISTRATION" (rangee 0)
    text = "ADMINISTRATION"
    tw = text_width(text) * 2
    bx0, bx1 = (176 - tw) // 2 - 8, (176 + tw) // 2 + 8
    for y in range(19, 34):
        for x in range(bx0, bx1):
            edge = x in (bx0, bx1 - 1) or y in (19, 33)
            px[x, y] = mix(dark, (0, 0, 0), 0.3) if edge else mix(mix(dark, panel_top, 0.25), panel_top, (y - 19) / 14)
    cx = (176 - tw) // 2
    for ch in text:
        g = FONT[ch]
        for yy, row in enumerate(g):
            for xx, v in enumerate(row):
                if v == "1":
                    for dx in range(2):
                        for dy in range(2):
                            px[cx + xx * 2 + dx + 1, 22 + yy * 2 + dy + 1] = hexc("#0d2a14")
                            px[cx + xx * 2 + dx, 22 + yy * 2 + dy] = (240, 255, 240, 255)
        cx += (len(g[0]) + 1) * 2
    # ornements de la banniere
    for k in range(3):
        for (x, y) in ((bx0 - 6 - k * 5, 26), (bx1 + 5 + k * 5, 26)):
            px[x, y] = light; px[x + 1, y] = light; px[x, y + 1] = dark; px[x + 1, y + 1] = dark
    def card(slot):
        r, c = divmod(slot, 9)
        x, y = 7 + c * 18, 17 + r * 18
        for yy in range(18):
            for xx in range(18):
                if (xx in (0, 17)) and (yy in (0, 17)):
                    continue
                X, Y = x + xx, y + yy
                if xx == 0 or yy == 0 or xx == 17 or yy == 17:
                    col = mix(light, dark, yy / 17)
                elif (xx == 1 or yy == 1) and not (xx == 16 or yy == 16):
                    col = mix(light, panel_top, 0.6)
                else:
                    col = mix(hexc("#26303d"), hexc("#161d26"), yy / 17)
                px[X, Y] = col
        # halo discret autour de la carte
        for (X, Y) in [(x - 1, y + k) for k in range(2, 16)] + [(x + 18, y + k) for k in range(2, 16)] + \
                      [(x + k, y - 1) for k in range(2, 16)] + [(x + k, y + 18) for k in range(2, 16)]:
            if 0 <= X < img.width and 0 <= Y < img.height:
                px[X, Y] = mix(px[X, Y], light, 0.18)
    for sl in HUB_BUTTONS:
        card(sl)
    # rangee des joueurs : cases sombres + filet lumineux dessous
    for sl in HUB_PLAYERS:
        r, c = divmod(sl, 9)
        x, y = 7 + c * 18, 17 + r * 18
        for yy in range(18):
            for xx in range(18):
                if (xx in (0, 17)) and (yy in (0, 17)):
                    continue
                px[x + xx, y + yy] = hexc("#0a0d12") if xx == 0 or yy == 0 else hexc("#2c3442") if xx == 17 or yy == 17 else hexc("#11161c")
    yl = 17 + 4 * 18 + 1
    for x in range(7 + 18, 7 + 8 * 18):
        t = abs(x - 88) / 70
        px[x, yl] = mix(light, panel_bot, 0.3 + t * 0.6)
    return img

def gui_space_provider():
    adv = {}
    for k in range(9):
        adv[chr(0xF001 + k)] = -(1 << k)   # -1 -2 -4 ... -256
        adv[chr(0xF011 + k)] = (1 << k)    # +1 +2 ... +256
    return {"type": "space", "advances": adv}

# ----------------------------------------------------------------- ecriture du pack
def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)

def main():
    tex = os.path.join(OUT, "assets/kiwilando/textures/item/admin")
    mdl = os.path.join(OUT, "assets/kiwilando/models/item/admin")
    itm = os.path.join(OUT, "assets/kiwilando/items/admin")
    fnt = os.path.join(OUT, "assets/kiwilando/textures/font/badges")
    for d in (tex, mdl, itm, fnt):
        os.makedirs(d, exist_ok=True)

    icons = {}
    for name, fn in ICONS.items():
        ic = Icon()
        fn(ic)
        ic.shadow()
        ic.img.save(os.path.join(tex, name + ".png"))
        icons[name] = ic.img
        write_json(os.path.join(mdl, name + ".json"),
                   {"parent": "minecraft:item/generated", "textures": {"layer0": "kiwilando:item/admin/" + name}})
        write_json(os.path.join(itm, name + ".json"),
                   {"model": {"type": "minecraft:model", "model": "kiwilando:item/admin/" + name}})

    providers = []
    badges = {}
    for bid, text, top, bottom, sym, ch in BADGES:
        img = badge(text, top, bottom, sym)
        img.save(os.path.join(fnt, bid + ".png"))
        badges[bid] = img
        providers.append({"type": "bitmap", "file": "kiwilando:font/badges/" + bid + ".png",
                          "ascent": 8, "height": 9, "chars": [chr(ch)]})
    write_json(os.path.join(OUT, "assets/kiwilando/font/badges.json"), {"providers": providers})

    gdir = os.path.join(OUT, "assets/kiwilando/textures/font/gui")
    os.makedirs(gdir, exist_ok=True)
    gproviders = [gui_space_provider()]
    guis = {}
    for ti, theme in enumerate(THEME_ORDER):
        for rows in (3, 4, 5, 6):
            img = gui_bg(rows, theme)
            name = "%s_%d" % (theme, rows)
            img.save(os.path.join(gdir, name + ".png"))
            guis[name] = img
            gproviders.append({"type": "bitmap", "file": "kiwilando:font/gui/" + name + ".png",
                               "ascent": 13, "height": img.height, "chars": [chr(0xE200 + ti * 4 + rows - 3)]})
    hubimg = gui_hub()
    hubimg.save(os.path.join(gdir, "hub.png"))
    guis["hub"] = hubimg
    gproviders.append({"type": "bitmap", "file": "kiwilando:font/gui/hub.png", "ascent": 13, "height": hubimg.height, "chars": [chr(0xE210)]})
    write_json(os.path.join(OUT, "assets/kiwilando/font/gui.json"), {"providers": gproviders})

    # menus des jeux : meme style que le staff (fini les deux looks differents)
    mdir = os.path.join(OUT, "assets/kiwilando/textures/gui")
    os.makedirs(mdir, exist_ok=True)
    mproviders = [{"type": "space", "advances": {"\ue100": -8, "\ue101": -169}}]
    for ti, (gid, _l, _d) in enumerate(GAME_THEMES):
        for k, rows in enumerate((3, 6)):
            img = gui_bg(rows, "game_" + gid)
            name = "menu_%s_%d" % (gid, rows)
            img.save(os.path.join(mdir, name + ".png"))
            mproviders.append({"type": "bitmap", "file": "kiwilando:gui/" + name + ".png",
                               "ascent": 13, "height": img.height, "chars": [chr(0xE200 + ti * 2 + k)]})
    write_json(os.path.join(OUT, "assets/kiwilando/font/menu.json"), {"providers": mproviders})
    globals()["GUIS"] = guis

    if not os.path.exists(os.path.join(OUT, "pack.mcmeta")):
      write_json(os.path.join(OUT, "pack.mcmeta"), {"pack": {
        "description": "Kiwilando - badges, icones et menus du staff",
        "min_format": 84, "max_format": 97}})
    # icone du pack : grand bouclier
    ic = Icon(32); ICONS["anticheat"](ic); ic.shadow()
    if not os.path.exists(os.path.join(OUT, "pack.png")):
        ic.img.resize((128, 128), Image.NEAREST).save(os.path.join(OUT, "pack.png"))

    # apercu
    cols = 8
    rows = math.ceil(len(icons) / cols)
    prev = Image.new("RGBA", (cols * 80 + 20, rows * 80 + 30 + len(badges) * 44 + 20), (139, 139, 139, 255))
    # fond facon inventaire Minecraft
    d = ImageDraw.Draw(prev)
    for idx, (name, img) in enumerate(icons.items()):
        x, y = 10 + (idx % cols) * 80, 10 + (idx // cols) * 80
        d.rectangle((x, y, x + 72, y + 72), fill=(55, 55, 55, 255))
        d.rectangle((x + 2, y + 2, x + 72, y + 72), fill=(139, 139, 139, 255))
        d.rectangle((x + 2, y + 2, x + 70, y + 70), fill=(198, 198, 198, 255) if False else (139, 139, 139, 255))
        prev.alpha_composite(img.resize((64, 64), Image.NEAREST), (x + 4, y + 4))
    y = 30 + rows * 80
    d.rectangle((0, y - 10, prev.width, prev.height), fill=(30, 30, 30, 255))
    for bid, img in badges.items():
        big = img.resize((img.width * 2, img.height * 2), Image.NEAREST)
        prev.alpha_composite(big, (14, y))
        d.text((big.width + 30, y + 10), "<pseudo> salut tout le monde !", fill=(255, 255, 255, 255))
        y += 44
    prev.save(os.path.join(os.path.dirname(os.path.abspath(OUT)), "apercu.png"))

    zpath = os.path.join(os.path.dirname(os.path.abspath(OUT)), "Kiwilando-Pack.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(OUT):
            for f in sorted(files):
                full = os.path.join(root, f)
                z.write(full, os.path.relpath(full, OUT))
    print("icones:", len(icons), "badges:", len(badges), "->", zpath)

if __name__ == "__main__":
    main()
