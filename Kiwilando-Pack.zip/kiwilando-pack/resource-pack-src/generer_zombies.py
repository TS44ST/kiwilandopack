#!/usr/bin/env python3
"""Pack zombies : armes en 3D (10 armes x 6 niveaux), bonus a ramasser en 3D, icones des atouts.

Usage : python3 generer_zombies.py <dossier resource-pack> [apercu.png]
 -> ecrit models/item, items et textures/item dans assets/kiwilando, puis refait Kiwilando-Pack.zip
    (a cote du dossier du pack) et, si demande, une image d'apercu.

Les armes pointent vers le nord (-Z) : c'est "devant" quand on les tient.
Toutes les faces prennent leur couleur dans une palette (textures/item/zpal.png).
"""
import json, os, sys, zipfile
from PIL import Image, ImageDraw

OUT = sys.argv[1] if len(sys.argv) > 1 else "resource-pack"
PREVIEW = sys.argv[2] if len(sys.argv) > 2 else None
A = os.path.join(OUT, "assets", "kiwilando")

# ------------------------------------------------------------------ palette
PAL = {
    "black": "17181b", "dark": "2e3238", "metal": "555b63", "light": "8a9099", "white": "e8eaee",
    "wood": "7a4a22", "woodd": "55310f", "red": "b8322e", "cyan": "3fd6e8", "cyand": "1f8fa8",
    "purple": "8e4fd0", "purpled": "5b2f91", "brass": "c9a13a", "green": "4a6b35", "greend": "32491f",
    "orange": "e07b24", "yellow": "f2d43a", "gold": "f5c542", "goldd": "b8862b", "ice": "a8ecff",
    "iced": "5cc3ef", "bone": "e9e4d4", "boned": "b9b29b", "emerald": "34c26b", "emeraldd": "1e8a47",
    "crimson": "e23b3b", "pink": "f08ad0", "blue": "3f8be8", "lime": "7ad63f",
    # equipes de paintball (couleur, couleur sombre)
    "trouge": "e04444", "trouged": "a82c2c", "tbleu": "4b89ff", "tbleud": "2f5fc4", "tvert": "4fc85a",
    "tvertd": "2f8f3c", "tjaune": "ffe03e", "tjauned": "c9a020", "tneutre": "c9ced6", "tneutred": "8a9099",
    # accents des niveaux d'amelioration (a0 = arme de base)
    "a0": "8a9099", "a1": "4fc04f", "a2": "3f8be8", "a3": "a04fe0", "a4": "f0622e", "a5": "f5c542",
}
NAMES = list(PAL)
COLS = 8   # palette 8 x 8 cases de 4 px


def rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def palette_png():
    im = Image.new("RGBA", (32, 32), (0, 0, 0, 255))
    d = ImageDraw.Draw(im)
    for i, n in enumerate(NAMES):
        x, y = (i % COLS) * 4, (i // COLS) * 4
        d.rectangle([x, y, x + 3, y + 3], fill=rgb(PAL[n]) + (255,))
    im.save(os.path.join(A, "textures", "item", "zpal.png"))


def uv(color):
    i = NAMES.index(color)
    u, v = (i % COLS) * 2, (i // COLS) * 2
    return [u + 0.5, v + 0.5, u + 1.5, v + 1.5]


def element(b, accent):
    x1, y1, z1, x2, y2, z2, c = b
    if c == "acc":
        c = accent
    f = {"uv": uv(c), "texture": "#p"}
    return {"from": [x1, y1, z1], "to": [x2, y2, z2],
            "faces": {k: dict(f) for k in ("north", "east", "south", "west", "up", "down")}}


def jdump(obj, *p):
    path = os.path.join(A, *p)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=1)


GUN_DISPLAY = {
    "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3.0, 1.5], "scale": [0.85, 0.85, 0.85]},
    "thirdperson_lefthand": {"rotation": [0, 0, 0], "translation": [0, 3.0, 1.5], "scale": [0.85, 0.85, 0.85]},
    "firstperson_righthand": {"rotation": [0, 0, 0], "translation": [1.5, 3.5, -1.0], "scale": [0.85, 0.85, 0.85]},
    "firstperson_lefthand": {"rotation": [0, 0, 0], "translation": [1.5, 3.5, -1.0], "scale": [0.85, 0.85, 0.85]},
    "gui": {"rotation": [18, -118, 0], "translation": [0.5, 0.5, 0], "scale": [0.82, 0.82, 0.82]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.6, 0.6, 0.6]},
    "fixed": {"rotation": [0, -90, 0], "translation": [0, 0, 0], "scale": [0.9, 0.9, 0.9]},
}
# Visee du paintball. Calcul (rendu 1re personne) : main droite en (0.56, -0.52, -0.72) bloc, modele centre sur 8 px.
#  x : 0.56 + tx/16 = 0                         -> tx = -8.96 (lanceur au milieu de l'ecran)
#  y : -0.52 + ty/16 + s * (16.2/16 - 0.5) = -0.03 -> haut du reservoir (16.2 px) juste sous la croix (s = 0.85)
ADS_DISPLAY = {"rotation": [0, 0, 0], "translation": [-8.96, 0.9, 0.5], "scale": [0.85, 0.85, 0.85]}
ICON_DISPLAY = {
    "gui": {"rotation": [25, -35, 0], "translation": [0, 0, 0], "scale": [0.8, 0.8, 0.8]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.6, 0.6, 0.6]},
    "fixed": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [1, 1, 1]},
}


def write_model(name, boxes, accent="a0", display=None):
    jdump({"textures": {"p": "kiwilando:item/zpal", "particle": "kiwilando:item/zpal"},
           "elements": [element(b, accent) for b in boxes], "display": display or GUN_DISPLAY},
          "models", "item", name + ".json")
    jdump({"model": {"type": "minecraft:model", "model": "kiwilando:item/" + name}}, "items", name + ".json")


# ------------------------------------------------------------------ armes (x centre sur 8, canon vers -Z)
def B(x1, y1, z1, x2, y2, z2, c):
    return (x1, y1, z1, x2, y2, z2, c)


GUNS = {
    "pistol": [
        B(7, 9, 3, 9, 11.2, 11, "metal"), B(7.2, 11.2, 3.5, 8.8, 11.6, 10.5, "light"),
        B(7.5, 9.6, 2, 8.5, 10.6, 3, "black"), B(7, 4, 8.2, 9, 9, 11, "wood"),
        B(6.9, 4, 8.6, 9.1, 5, 10.6, "woodd"), B(7.6, 7.2, 5.8, 8.4, 7.8, 8.2, "dark"),
        B(7.6, 7.8, 5.8, 8.4, 9, 6.4, "dark"), B(7.5, 11.6, 9.8, 8.5, 12.2, 10.6, "acc"),
        B(7.6, 11.6, 3.6, 8.4, 12.0, 4.2, "acc"),
    ],
    "magnum": [
        B(7.25, 9.6, -1, 8.75, 11, 7, "light"), B(7.5, 8.9, 0, 8.5, 9.6, 6.5, "metal"),
        B(6.4, 8.4, 7, 9.6, 11.6, 10.2, "metal"), B(6.2, 9.2, 7.4, 9.8, 10.8, 9.8, "light"),
        B(7, 8.8, 10.2, 9, 11.2, 12.2, "light"), B(7, 3.6, 10, 9, 9, 12.6, "wood"),
        B(6.9, 3.6, 10.4, 9.1, 4.8, 12.2, "woodd"), B(7.5, 11.2, 11.4, 8.5, 12.4, 12.4, "acc"),
        B(7.6, 11, -0.6, 8.4, 11.8, 0.2, "acc"), B(7.6, 7, 7.2, 8.4, 7.6, 9.8, "dark"),
        B(7.6, 7.6, 7.2, 8.4, 8.6, 7.8, "dark"),
    ],
    "shotgun": [
        B(7.25, 10, -5, 8.75, 11.5, 9, "dark"), B(7.4, 8.8, -4, 8.6, 10, 9, "metal"),
        B(6.7, 8.2, -1, 9.3, 10.2, 4.5, "wood"), B(6.7, 8.2, 0, 9.3, 8.6, 0.6, "woodd"),
        B(6.7, 8.2, 1.6, 9.3, 8.6, 2.2, "woodd"), B(6.7, 8.2, 3.2, 9.3, 8.6, 3.8, "woodd"),
        B(7, 8.4, 9, 9, 11.7, 13.5, "metal"), B(7, 7, 13.5, 9, 11, 16, "wood"),
        B(7, 6.2, 16, 9, 10.6, 21, "wood"), B(6.9, 6, 20.4, 9.1, 10.8, 21.4, "woodd"),
        B(7.6, 6.8, 10, 8.4, 7.4, 12.6, "dark"), B(7.6, 7.4, 10, 8.4, 8.4, 10.6, "dark"),
        B(7.6, 11.5, -4.6, 8.4, 12.1, -3.8, "acc"), B(7.1, 11.7, 9.6, 8.9, 12.1, 12.8, "acc"),
    ],
    "smg": [
        B(7, 8, 3, 9, 11.2, 12, "metal"), B(7.5, 9.2, -1, 8.5, 10.2, 3, "black"),
        B(7.1, 8.6, 0.5, 8.9, 10.8, 3, "dark"), B(7.25, 2.6, 5.6, 8.75, 8, 7.6, "black"),
        B(7.15, 2.2, 5.5, 8.85, 3.0, 7.7, "acc"), B(7, 3.8, 9.6, 9, 8, 11.8, "dark"),
        B(7.5, 9.6, 12, 8.5, 10.4, 17.5, "dark"), B(7.5, 7.6, 12, 8.5, 8.2, 17.5, "dark"),
        B(7, 7, 17.5, 9, 11, 18.6, "black"), B(7.4, 11.2, 4, 8.6, 12.2, 5, "acc"),
        B(7.4, 11.2, 10.4, 8.6, 12.0, 11.4, "light"), B(7.6, 6.6, 7.8, 8.4, 7.2, 9.6, "dark"),
    ],
    "ar": [
        B(7.5, 9.5, -6, 8.5, 10.5, 2, "black"), B(7.3, 9.3, -6.6, 8.7, 10.7, -5.4, "dark"),
        B(6.7, 8.7, 1.5, 9.3, 11.3, 8, "dark"), B(6.6, 9.4, 2.4, 9.4, 10.2, 3.2, "black"),
        B(6.6, 9.4, 4.2, 9.4, 10.2, 5.0, "black"), B(6.6, 9.4, 6.0, 9.4, 10.2, 6.8, "black"),
        B(7, 8, 8, 9, 11.5, 14.5, "metal"), B(7.25, 3.4, 9, 8.75, 8, 11.6, "black"),
        B(7.15, 3.0, 8.6, 8.85, 3.8, 11.4, "acc"), B(7, 4, 13, 9, 8, 15, "dark"),
        B(7.3, 9.4, 14.5, 8.7, 10.6, 17, "dark"), B(7, 7.4, 17, 9, 11.2, 21.5, "woodd"),
        B(6.9, 7.2, 21, 9.1, 11.4, 22, "black"), B(7.5, 11.5, 9, 8.5, 12.1, 13.5, "light"),
        B(7.5, 12.1, 9, 8.5, 12.9, 9.8, "acc"), B(7.5, 12.1, 12.7, 8.5, 12.9, 13.5, "acc"),
        B(7.6, 10.5, -4.6, 8.4, 12.2, -3.8, "light"), B(7.6, 6.8, 11.8, 8.4, 7.4, 13, "dark"),
    ],
    "sniper": [
        B(7.5, 9.5, -11, 8.5, 10.5, 4, "black"), B(7.2, 9.2, -12.5, 8.8, 10.8, -10.5, "dark"),
        B(7, 8.5, 4, 9, 11.2, 13.5, "metal"), B(7.1, 8.0, 0, 8.9, 9.5, 4, "wood"),
        B(7.2, 11.9, 4.5, 8.8, 13.5, 12.5, "black"), B(7.0, 11.7, 3.4, 9.0, 13.7, 4.6, "dark"),
        B(7.0, 11.7, 12.4, 9.0, 13.7, 13.6, "dark"), B(7.3, 12.0, 3.2, 8.7, 13.4, 3.5, "cyan"),
        B(7.6, 11.2, 6, 8.4, 11.9, 7, "acc"), B(7.6, 11.2, 10, 8.4, 11.9, 11, "acc"),
        B(7, 7, 13.5, 9, 11, 16, "wood"), B(7, 5.8, 16, 9, 10.8, 22.5, "wood"),
        B(6.9, 5.6, 22, 9.1, 11, 23, "black"), B(7, 4.2, 12, 9, 8.5, 14, "woodd"),
        B(7.3, 6.4, 8, 8.7, 8.5, 10.5, "black"), B(6.6, 5, -6, 7.2, 9.6, -5.4, "dark"),
        B(8.8, 5, -6, 9.4, 9.6, -5.4, "dark"), B(7.6, 7, 10.8, 8.4, 7.6, 12, "dark"),
    ],
    "raygun": [
        B(6.5, 8, 4, 9.5, 11.5, 11, "cyan"), B(6.3, 9.2, 5, 9.7, 10.3, 10, "cyand"),
        B(7, 8.5, 1.5, 9, 11, 4, "purple"), B(6.6, 8.1, 0.5, 9.4, 11.4, 1.5, "red"),
        B(7.3, 8.8, -1, 8.7, 10.7, 0.5, "brass"), B(7.6, 9.2, -2.2, 8.4, 10.3, -1, "yellow"),
        B(6.8, 8.3, 11, 9.2, 11.2, 13, "purple"), B(7.2, 8.8, 13, 8.8, 10.7, 14, "red"),
        B(7.6, 11.5, 5, 8.4, 13.2, 6, "acc"), B(7.6, 11.5, 6, 8.4, 12.6, 9.5, "acc"),
        B(7, 3.6, 8, 9, 8, 10.6, "purpled"), B(6.9, 3.4, 8.2, 9.1, 4.4, 10.4, "brass"),
        B(7.6, 6.6, 5.6, 8.4, 7.2, 8, "brass"), B(7.6, 7.2, 5.6, 8.4, 8, 6.2, "brass"),
    ],
    "lmg": [
        B(7.5, 9.5, -8, 8.5, 10.5, 3, "black"), B(7.2, 9.2, -9, 8.8, 10.8, -7.6, "dark"),
        B(7, 9, -3, 9, 11, 3, "dark"), B(6.9, 9.6, -2.2, 9.1, 10.4, -1.4, "black"),
        B(6.9, 9.6, -0.4, 9.1, 10.4, 0.4, "black"), B(6.9, 9.6, 1.4, 9.1, 10.4, 2.2, "black"),
        B(6.7, 8, 3, 9.3, 11.6, 13, "metal"), B(5.2, 4.2, 4.8, 10.8, 8, 10.2, "green"),
        B(5.0, 7.4, 4.6, 11.0, 8.2, 10.4, "greend"), B(9.3, 8.4, 5.6, 10.6, 9.4, 9.4, "brass"),
        B(7, 3.8, 11, 9, 8, 13, "dark"), B(7, 7.4, 13, 9, 11.2, 20, "woodd"),
        B(6.9, 7.2, 19.6, 9.1, 11.4, 20.6, "black"), B(7.4, 11.6, 5, 8.6, 12.2, 6, "dark"),
        B(7.4, 11.6, 10, 8.6, 12.2, 11, "dark"), B(7.4, 12.2, 5, 8.6, 12.9, 11, "acc"),
        B(6.4, 4.6, -5, 7.0, 9.4, -4.4, "dark"), B(9.0, 4.6, -5, 9.6, 9.4, -4.4, "dark"),
        B(7.6, 10.5, -6.4, 8.4, 12, -5.6, "light"),
    ],
    "flame": [
        B(7.5, 9.5, -6, 8.5, 10.5, 6, "metal"), B(7, 9, -8.5, 9, 11, -6, "dark"),
        B(6.8, 8.8, -9.2, 9.2, 11.2, -8.5, "black"), B(7.5, 8.2, -8.4, 8.5, 9.0, -6.6, "orange"),
        B(7.6, 7.6, -9.4, 8.4, 8.4, -8.6, "yellow"), B(7, 8.5, 6, 9, 11.2, 11, "dark"),
        B(5.6, 6, 11, 8.0, 12.4, 17.5, "red"), B(8.0, 6, 11, 10.4, 12.4, 17.5, "orange"),
        B(5.8, 12.4, 12, 7.8, 13.2, 16.5, "light"), B(8.2, 12.4, 12, 10.2, 13.2, 16.5, "light"),
        B(5.4, 8.6, 13, 10.6, 9.8, 14.2, "acc"), B(7.25, 4.6, 1.4, 8.75, 9.5, 3.4, "woodd"),
        B(7, 4.2, 8, 9, 8.5, 10, "woodd"), B(7.6, 8.0, 3.4, 8.4, 8.7, 8, "brass"),
        B(7.6, 10.5, -2, 8.4, 11.3, -1, "acc"),
    ],
    "rpg": [
        B(6.75, 9, -6, 9.25, 11.5, 18, "green"), B(6.55, 8.8, -6.6, 9.45, 11.7, -5.4, "greend"),
        B(6.5, 8.75, -11, 9.5, 11.75, -7, "greend"), B(6.9, 9.15, -12.6, 9.1, 11.35, -11, "green"),
        B(7.3, 9.55, -14.2, 8.7, 10.95, -12.6, "acc"), B(7.4, 9.65, -7, 8.6, 10.85, -6, "dark"),
        B(6.25, 8.5, 18, 9.75, 12, 19.4, "greend"), B(5.9, 8.15, 19.4, 10.1, 12.35, 21, "dark"),
        B(6.5, 8.75, 10, 9.5, 11.75, 14, "wood"), B(7, 4.4, 3.6, 9, 9, 5.8, "wood"),
        B(7, 4.4, 8, 9, 9, 10, "woodd"), B(7.6, 7.2, 5.8, 8.4, 7.8, 8, "dark"),
        B(7.5, 11.5, 2.6, 8.5, 13.6, 3.4, "dark"), B(7.3, 13.0, 2.5, 8.7, 13.8, 3.5, "acc"),
        B(7.5, 11.5, 12, 8.5, 12.8, 12.8, "dark"),
    ],
}

# couteau de combat (lame vers -Z)
KNIFE = [
    B(7.7, 8.2, -3, 8.3, 10.2, 6, "light"), B(7.8, 7.6, -1.5, 8.2, 8.2, 6, "white"),
    B(7.75, 9.0, -4.4, 8.25, 10.2, -3, "light"), B(7.8, 9.6, -5.4, 8.2, 10.2, -4.4, "white"),
    B(7.7, 10.2, 1, 8.3, 10.6, 6, "metal"), B(7.2, 7, 6, 8.8, 11, 7, "dark"),
    B(7.4, 7.8, 7, 8.6, 10, 12, "black"), B(7.3, 7.7, 8, 8.7, 10.1, 8.6, "woodd"),
    B(7.3, 7.7, 9.6, 8.7, 10.1, 10.2, "woodd"), B(7.3, 7.6, 12, 8.7, 10.2, 13, "metal"),
]


def paintgun(c, cd):
    """Lanceur de paintball : corps a la couleur de l'equipe, reservoir de billes au-dessus, bouteille d'air."""
    return [
        B(7, 8.5, 3, 9, 11, 12, c), B(6.9, 9.4, 4, 9.1, 10.1, 11, cd),
        B(7.5, 9.3, -6, 8.5, 10.3, 3, "black"), B(7.3, 9.1, -7, 8.7, 10.5, -5.6, "dark"),
        B(7.2, 9.0, 1.5, 8.8, 10.6, 3, "dark"),
        B(7.4, 11, 6.5, 8.6, 12, 8.5, "dark"),                       # col du reservoir
        B(6.2, 12, 4.5, 9.8, 15.5, 10.5, "white"), B(6.6, 15.5, 5, 9.4, 16.2, 10, c),
        B(6.0, 13.2, 5.2, 10.0, 14.4, 9.8, cd),
        B(7, 3.8, 9.5, 9, 8.5, 11.5, "dark"), B(7.2, 4.4, 4, 8.8, 8.5, 5.6, "dark"),   # poignees
        B(7.6, 7.2, 7, 8.4, 7.8, 9.5, "black"),
        B(7.1, 5.2, 12, 8.9, 8.2, 19, "light"), B(7.3, 5.4, 19, 8.7, 8.0, 20, "metal"),   # bouteille d'air
        B(7.4, 8.2, 12, 8.6, 9.2, 14, "dark"), B(7.5, 11, 3.6, 8.5, 11.8, 4.4, c),
    ]


# ------------------------------------------------------------------ bonus a ramasser (centres sur 8, 8, 8)
def letters(text, x0, y0, z1, z2, color, px=1.0):
    """Lettres en pixels (plaque d'epaisseur z1..z2). Grille 5 de haut."""
    font = {
        "X": ["1...1", ".1.1.", "..1..", ".1.1.", "1...1"],
        "2": ["1111.", "....1", ".111.", "1....", "11111"],
        "$": [".1111", "1.1..", ".111.", "..1.1", "1111."],
        "%": ["11..1", "11.1.", "..1..", ".1.11", "1..11"],
    }
    out = []
    x = x0
    for ch in text:
        rows = font[ch]
        for r, row in enumerate(rows):
            for c, v in enumerate(row):
                if v == "1":
                    out.append(B(x + c * px, y0 + (4 - r) * px, z1, x + (c + 1) * px, y0 + (5 - r) * px, z2, color))
        x += 6 * px
    return out


POWER = {
    "max_ammo": [
        B(3, 3, 4.5, 13, 9, 11.5, "green"), B(2.8, 8.4, 4.3, 13.2, 9.4, 11.7, "greend"),
        B(2.8, 3, 4.3, 13.2, 3.8, 11.7, "greend"), B(7, 5, 4.2, 9, 7, 4.5, "yellow"),
        B(7, 5, 11.5, 9, 7, 11.8, "yellow"),
        B(4, 9.4, 7, 5.4, 12.6, 8.4, "brass"), B(4.3, 12.6, 7.3, 5.1, 13.6, 8.1, "orange"),
        B(6.3, 9.4, 7, 7.7, 12.6, 8.4, "brass"), B(6.6, 12.6, 7.3, 7.4, 13.6, 8.1, "orange"),
        B(8.6, 9.4, 7, 10, 12.6, 8.4, "brass"), B(8.9, 12.6, 7.3, 9.7, 13.6, 8.1, "orange"),
        B(10.9, 9.4, 7, 12.3, 12.6, 8.4, "brass"), B(11.2, 12.6, 7.3, 12, 13.6, 8.1, "orange"),
    ],
    "insta_kill": [
        B(4, 6, 4.5, 12, 13, 11.5, "bone"), B(4.6, 13, 5.1, 11.4, 13.8, 10.9, "bone"),
        B(5.2, 3.6, 5, 10.8, 6, 10.5, "boned"), B(5.2, 8.2, 4.2, 7.2, 10.4, 4.6, "black"),
        B(8.8, 8.2, 4.2, 10.8, 10.4, 4.6, "black"), B(7.5, 6.4, 4.2, 8.5, 7.6, 4.6, "black"),
        B(5.8, 3.6, 4.7, 6.6, 5.2, 5.1, "bone"), B(7.1, 3.6, 4.7, 7.9, 5.2, 5.1, "bone"),
        B(8.3, 3.6, 4.7, 9.1, 5.2, 5.1, "bone"), B(9.5, 3.6, 4.7, 10.3, 5.2, 5.1, "bone"),
        B(5.6, 8.8, 4.1, 6.4, 9.8, 4.3, "crimson"), B(9.6, 8.8, 4.1, 10.4, 9.8, 4.3, "crimson"),
    ],
    "double_points": letters("X2", 2.5, 4.5, 6.8, 9.2, "gold", 1.4) + [B(1.5, 2.6, 6.4, 14.5, 3.6, 9.6, "goldd")],
    "nuke": [
        B(5, 4, 5, 11, 11, 11, "dark"), B(5.6, 2.6, 5.6, 10.4, 4, 10.4, "black"),
        B(5.6, 11, 5.6, 10.4, 12.2, 10.4, "dark"), B(4.8, 6.6, 4.8, 11.2, 8.4, 11.2, "yellow"),
        B(7.4, 12.2, 7.4, 8.6, 13.4, 8.6, "light"), B(4, 12.4, 7.6, 12, 14.6, 8.4, "red"),
        B(7.6, 12.4, 4, 8.4, 14.6, 12, "red"), B(7, 6.9, 4.6, 9, 8.1, 4.9, "black"),
    ],
    "fire_sale": [
        B(3, 3, 4.5, 13, 8.5, 11.5, "purple"), B(2.8, 8.5, 4.3, 13.2, 11.5, 11.7, "purpled"),
        B(2.8, 8.2, 4.3, 13.2, 8.8, 11.7, "gold"), B(7.2, 6.8, 4.0, 8.8, 9.4, 4.5, "gold"),
        B(4.2, 3, 4.3, 5, 8.5, 11.7, "gold"), B(11, 3, 4.3, 11.8, 8.5, 11.7, "gold"),
    ] + letters("%", 5.9, 11.9, 7.4, 8.6, "pink", 0.85),
    "freeze": [
        B(7, 2.5, 7, 9, 13.5, 9, "ice"), B(5.6, 4.5, 6.4, 7, 10.5, 9.6, "iced"),
        B(9, 5.5, 6.4, 10.6, 11.5, 9.6, "iced"), B(6.4, 4, 5.2, 9.6, 9, 7, "ice"),
        B(6.4, 6, 9, 9.6, 12, 10.8, "ice"), B(4.4, 6.5, 7.2, 5.6, 8.5, 8.8, "white"),
        B(10.6, 8, 7.2, 11.8, 10, 8.8, "white"), B(7.4, 13.5, 7.4, 8.6, 14.6, 8.6, "white"),
    ],
    "bonus_points": [
        B(3, 3, 5.5, 8, 5.4, 10.5, "gold"), B(8.4, 3, 5.5, 13.4, 5.4, 10.5, "gold"),
        B(5.6, 5.6, 5.5, 10.6, 8, 10.5, "gold"), B(3.2, 5.4, 5.7, 7.8, 5.6, 10.3, "goldd"),
        B(8.6, 5.4, 5.7, 13.2, 5.6, 10.3, "goldd"), B(6.4, 8.4, 6.4, 9.6, 11.6, 9.6, "emerald"),
        B(7, 11.6, 7, 9, 12.8, 9, "emeraldd"), B(5.8, 9.2, 7, 6.4, 10.8, 9, "emeraldd"),
        B(9.6, 9.2, 7, 10.2, 10.8, 9, "emeraldd"),
    ],
    "medic": [
        B(3, 3.5, 5, 13, 11, 11, "white"), B(2.8, 10.4, 4.8, 13.2, 11.4, 11.2, "light"),
        B(6.2, 11.4, 7.2, 9.8, 12.6, 8.8, "dark"), B(7.1, 4.8, 4.6, 8.9, 9.8, 5, "crimson"),
        B(5.5, 6.4, 4.6, 10.5, 8.2, 5, "crimson"), B(7.1, 4.8, 11, 8.9, 9.8, 11.4, "crimson"),
        B(5.5, 6.4, 11, 10.5, 8.2, 11.4, "crimson"),
    ],
}

# ------------------------------------------------------------------ atouts : bouteilles 2D (16 x 16)
PERKS = {   # nom : (couleur du liquide, couleur sombre, symbole)
    "juggernog": ("crimson", "red", "heart"), "speed_cola": ("lime", "green", "bolt"),
    "double_tap": ("orange", "goldd", "two"), "quick_revive": ("iced", "blue", "cross"),
    "stamin_up": ("yellow", "goldd", "arrow"), "phd": ("purple", "purpled", "boom"),
    "deadshot": ("light", "dark", "target"), "electric": ("pink", "purple", "spark"),
}
SYMBOLS = {
    "heart": [".1.1.", "11111", "11111", ".111.", "..1.."],
    "bolt": ["..11.", ".11..", "1111.", "..11.", ".11.."],
    "two": ["1.1.1", "1.1.1", "1.1.1", "1.1.1", "1.1.1"],
    "cross": ["..1..", "..1..", "11111", "..1..", "..1.."],
    "arrow": ["..1..", ".111.", "1.1.1", "..1..", "..1.."],
    "boom": ["1.1.1", ".111.", "11111", ".111.", "1.1.1"],
    "target": [".111.", "1...1", "1.1.1", "1...1", ".111."],
    "spark": ["1...1", ".1.1.", "..1..", ".1.1.", "1...1"],
}


def perk_png(name, liquid, dark, symbol):
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    px = im.load()
    out = rgb(PAL["black"]) + (255,)
    lq, dk = rgb(PAL[liquid]) + (255,), rgb(PAL[dark]) + (255,)
    cap, capd = rgb(PAL["light"]) + (255,), rgb(PAL["metal"]) + (255,)
    white = rgb(PAL["white"]) + (255,)
    for y in range(16):
        if y in (0, 1):
            w = range(6, 10)        # capsule
        elif y in (2, 3, 4):
            w = range(6, 10)        # goulot
        elif y == 5:
            w = range(5, 11)
        else:
            w = range(4, 12)        # corps
        for x in w:
            if y <= 1:
                px[x, y] = cap if x < 8 else capd
            else:
                px[x, y] = lq if x < 9 else dk
    # contour
    src = im.copy().load()
    for y in range(16):
        for x in range(16):
            if src[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < 16 and 0 <= ny < 16 and src[nx, ny][3]:
                        px[x, y] = out
                        break
    # reflet + etiquette
    for y in range(6, 15):
        px[5, y] = white if y < 9 else px[5, y]
    for y in range(8, 15):
        for x in range(5, 11):
            px[x, y] = white
    rows = SYMBOLS[symbol]
    for r, row in enumerate(rows):
        for c, v in enumerate(row):
            if v == "1":
                px[5 + c + (0 if len(row) == 5 else 0), 9 + r] = dk
    for x in range(5, 11):
        px[x, 8] = dk
    im.save(os.path.join(A, "textures", "item", "zperk_" + name + ".png"))
    jdump({"parent": "minecraft:item/generated", "textures": {"layer0": "kiwilando:item/zperk_" + name}},
          "models", "item", "zperk_" + name + ".json")
    jdump({"model": {"type": "minecraft:model", "model": "kiwilando:item/zperk_" + name}}, "items", "zperk_" + name + ".json")


# ------------------------------------------------------------------ apercu (rendu simple des boites)
def render(boxes, accent, size=220, yaw=-55, pitch=18):
    import math
    cy, sy = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    cp, sp = math.cos(math.radians(pitch)), math.sin(math.radians(pitch))

    def proj(x, y, z):
        x, y, z = x - 8, y - 8, z - 6
        x, z = x * cy + z * sy, -x * sy + z * cy
        y, z = y * cp - z * sp, y * sp + z * cp
        return x, y, z

    faces = []
    shade = {"up": 1.0, "down": 0.5, "north": 0.8, "south": 0.8, "east": 0.6, "west": 0.6}
    for b in boxes:
        x1, y1, z1, x2, y2, z2, c = b
        c = accent if c == "acc" else c
        col = rgb(PAL[c])
        quads = {
            "up": [(x1, y2, z1), (x2, y2, z1), (x2, y2, z2), (x1, y2, z2)],
            "down": [(x1, y1, z1), (x2, y1, z1), (x2, y1, z2), (x1, y1, z2)],
            "north": [(x1, y1, z1), (x2, y1, z1), (x2, y2, z1), (x1, y2, z1)],
            "south": [(x1, y1, z2), (x2, y1, z2), (x2, y2, z2), (x1, y2, z2)],
            "west": [(x1, y1, z1), (x1, y1, z2), (x1, y2, z2), (x1, y2, z1)],
            "east": [(x2, y1, z1), (x2, y1, z2), (x2, y2, z2), (x2, y2, z1)],
        }
        for k, q in quads.items():
            pts = [proj(*p) for p in q]
            depth = sum(p[2] for p in pts) / 4
            faces.append((depth, [(p[0], p[1]) for p in pts], tuple(int(v * shade[k]) for v in col)))
    faces.sort(key=lambda f: -f[0])
    im = Image.new("RGBA", (size, size), (38, 42, 52, 255))
    d = ImageDraw.Draw(im)
    s = size / 36
    for _, pts, col in faces:
        d.polygon([(size / 2 + x * s, size / 2 - y * s) for x, y in pts], fill=col + (255,))
    return im


def preview(path):
    gl = list(GUNS)
    pl = list(POWER)
    W = 220
    im = Image.new("RGBA", (W * 5, W * 5 + 150), (24, 26, 32, 255))
    im.paste(render(KNIFE, "a0", W), (3 * W, 4 * W))
    im.paste(render(paintgun("trouge", "trouged"), "a0", W), (4 * W, 4 * W))
    for i, n in enumerate(gl):
        im.paste(render(GUNS[n], "a0", W), ((i % 5) * W, (i // 5) * W))
    for i in range(5):
        im.paste(render(GUNS["ar"], "a%d" % (i + 1), W), (i * W, 2 * W))
    for i, n in enumerate(pl):
        im.paste(render(POWER[n], "a0", W, yaw=-30, pitch=22), ((i % 5) * W, (3 + i // 5) * W))
    for i, n in enumerate(PERKS):
        t = Image.open(os.path.join(A, "textures", "item", "zperk_" + n + ".png")).resize((112, 112), Image.NEAREST)
        im.paste(t, (20 + i * 130, 5 * W + 20), t)
    im.save(path)


def main():
    os.makedirs(os.path.join(A, "textures", "item"), exist_ok=True)
    palette_png()
    for name, boxes in GUNS.items():
        # dans les menus : l'arme entiere doit tenir dans la case, centree
        z1 = min(b[2] for b in boxes)
        z2 = max(b[5] for b in boxes)
        scale = round(min(0.95, 15.0 / (z2 - z1)), 3)
        disp = dict(GUN_DISPLAY)
        disp["gui"] = {"rotation": [18, -118, 0],
                       "translation": [round(0.883 * ((z1 + z2) / 2 - 8) * scale, 2), 0.5, 0],
                       "scale": [scale, scale, scale]}
        disp["fixed"] = {"rotation": [0, -90, 0], "translation": [round(((z1 + z2) / 2 - 8) * scale, 2), 0, 0],
                         "scale": [scale, scale, scale]}
        write_model("zgun_" + name, boxes, "a0", disp)
        for lvl in range(1, 6):
            write_model("zgun_%s_l%d" % (name, lvl), boxes, "a%d" % lvl, disp)
    kd = dict(GUN_DISPLAY)
    kd["gui"] = {"rotation": [18, -118, 0], "translation": [-3.2, 0, 0], "scale": [0.82, 0.82, 0.82]}
    kd["firstperson_righthand"] = {"rotation": [0, 0, 0], "translation": [1.5, 3.0, 0], "scale": [0.9, 0.9, 0.9]}
    kd["firstperson_lefthand"] = kd["firstperson_righthand"]
    write_model("zknife", KNIFE, "a0", kd)
    for team in ("", "rouge", "bleu", "vert", "jaune"):
        key = "t" + (team or "neutre")
        boxes = paintgun(key, key + "d")
        z1 = min(b[2] for b in boxes)
        z2 = max(b[5] for b in boxes)
        scale = round(15.0 / (z2 - z1), 3)
        disp = dict(GUN_DISPLAY)
        disp["gui"] = {"rotation": [18, -118, 0], "translation": [round(0.883 * ((z1 + z2) / 2 - 8) * scale, 2), -1.5, 0],
                       "scale": [scale, scale, scale]}
        write_model("paintball_gun" + ("_" + team if team else ""), boxes, "a0", disp)
        # visee (clic droit) : le lanceur vient au centre de l'ecran, le haut du reservoir juste sous le viseur
        ads = dict(disp)
        ads["firstperson_righthand"] = dict(ADS_DISPLAY)
        ads["firstperson_lefthand"] = dict(ADS_DISPLAY, translation=[-ADS_DISPLAY["translation"][0]] + ADS_DISPLAY["translation"][1:])
        write_model("paintball_gun_ads" + ("_" + team if team else ""), boxes, "a0", ads)
    for name, boxes in POWER.items():
        write_model("zpower_" + name, boxes, "a0", ICON_DISPLAY)
    for name, (liquid, dark, symbol) in PERKS.items():
        perk_png(name, liquid, dark, symbol)
    # les anciennes textures 2D des armes ne servent plus
    for f in os.listdir(os.path.join(A, "textures", "item")):
        if f.startswith("zgun_") or f.startswith("paintball_gun") or f == "zknife.png":
            os.remove(os.path.join(A, "textures", "item", f))
    zpath = os.path.join(os.path.dirname(os.path.abspath(OUT)), "Kiwilando-Pack.zip")
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _, files in os.walk(OUT):
            for f in sorted(files):
                full = os.path.join(root, f)
                z.write(full, os.path.relpath(full, OUT))
    print("pack :", zpath)
    if PREVIEW:
        preview(PREVIEW)


if __name__ == "__main__":
    main()
